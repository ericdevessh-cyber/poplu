---
Task ID: 1
Agent: Main Orchestrator
Task: Build complete Poplu - Pop the Talking Balloons game

Work Log:
- Explored existing Next.js 16 project structure and dependencies
- Created Web Audio API sound system (sounds.ts) with 15+ unique sound effects for all balloon types and game events
- Defined 10 levels with progressive difficulty (levels.ts) including pop, time attack, score target, and avoid bombs game modes
- Built Zustand game state store (gameStore.ts) with full persistence, level progression, coins, skins, and daily rewards
- Built Balloon.tsx component with smooth float-up animation, wobble, special effects (golden glow, bomb fuse, slow aura, speed flames)
- Built PopEffect.tsx with particle burst, expanding rings, and emoji flash animations
- Built FloatingText.tsx with score pop-up animations
- Built HomeScreen.tsx with animated POPLU title, floating background balloons, and play button
- Built LevelSelectScreen.tsx with responsive grid, star ratings, locked/unlocked states, and NEW badge
- Built GameScreen.tsx with full game loop, HUD (progress bar, score, lives, timer, combo), pause overlay, and all balloon spawning logic
- Built LevelCompleteScreen.tsx with confetti animation, star rating reveal, coins display, and mystery box button
- Built GameOverScreen.tsx with sad animation, encouraging messages, and "almost there" feedback
- Built MysteryBoxScreen.tsx with box opening animation, sparkle particles, weighted random rewards, and coin rain
- Built ShopScreen.tsx with balloon skins and effects tabs, buy/equip functionality
- Built DailyRewardScreen.tsx with 7-day calendar, claim system, streak tracking
- Wired everything together in page.tsx with AnimatePresence screen transitions
- Updated globals.css with warm game theme (orange/amber tones) and custom animations
- Updated layout.tsx with game metadata, viewport settings, and touch prevention

Stage Summary:
- Complete Poplu game built as a Next.js 16 single-page application
- 10 levels with 5 balloon types + 4 special types (golden, bomb, slow, speed)
- Full sound system using Web Audio API (no external files needed)
- Persistent state with localStorage via Zustand persist
- All screens: Home, Level Select, Game, Level Complete, Game Over, Mystery Box, Daily Rewards, Shop
- Responsive design with kid-friendly 44px+ touch targets
- All lint checks pass cleanly
- Dev server running successfully with 200 responses
