// Level System for Poplu
// 50 Levels across 5 Worlds with increasing difficulty

export type BalloonType = 'silly' | 'gross' | 'ghost' | 'robot' | 'party';
export type SpecialBalloonType = 'golden' | 'bomb' | 'slow' | 'speed';
export type LevelGoalType = 'pop' | 'popColor' | 'avoidBombs' | 'timeAttack' | 'scoreTarget';

export interface LevelConfig {
  id: number;
  name: string;
  description: string;
  emoji: string;
  world: number;
  worldName: string;
  goal: number;
  goalType: LevelGoalType;
  timeLimit?: number;
  spawnRate: number;
  balloonSpeed: number;
  maxBalloons: number;
  balloonTypes: BalloonType[];
  hasBombs: boolean;
  hasGolden: boolean;
  hasSlow: boolean;
  hasSpeed: boolean;
  bombChance: number;
  goldenChance: number;
  slowChance: number;
  speedChance: number;
  starTimeThresholds: [number, number, number]; // [1★ max sec, 2★ max sec, 3★ max sec]
  reward: {
    coins: number;
    mysteryBox?: boolean;
  };
}

export const BALLOON_CONFIG = {
  silly: { emoji: '😜', color: '#FFD93D', secondaryColor: '#FF9A3C', label: 'Silly' },
  gross: { emoji: '🤢', color: '#6BCB77', secondaryColor: '#4AA85B', label: 'Gross' },
  ghost: { emoji: '👻', color: '#C4B5FD', secondaryColor: '#8B5CF6', label: 'Ghost' },
  robot: { emoji: '🤖', color: '#94A3B8', secondaryColor: '#64748B', label: 'Robot' },
  party: { emoji: '🎉', color: '#F472B6', secondaryColor: '#EC4899', label: 'Party' },
  golden: { emoji: '⭐', color: '#FBBF24', secondaryColor: '#F59E0B', label: 'Golden' },
  bomb: { emoji: '💣', color: '#374151', secondaryColor: '#1F2937', label: 'Bomb' },
  slow: { emoji: '🐢', color: '#60A5FA', secondaryColor: '#3B82F6', label: 'Slow' },
  speed: { emoji: '🔥', color: '#EF4444', secondaryColor: '#DC2626', label: 'Speed' },
} as const;

// ============================================================
// WORLD DATA
// ============================================================
const WORLDS = [
  { id: 1, name: 'Getting Started', emoji: '🎈', color: 'from-yellow-400 to-orange-400' },
  { id: 2, name: 'Challenge Zone', emoji: '⚔️', color: 'from-rose-400 to-pink-500' },
  { id: 3, name: 'Danger Zone', emoji: '💀', color: 'from-purple-500 to-indigo-500' },
  { id: 4, name: 'Expert Zone', emoji: '👑', color: 'from-cyan-400 to-blue-500' },
  { id: 5, name: 'Master Zone', emoji: '🌟', color: 'from-amber-400 to-red-500' },
];

// Level name templates per world
const WORLD_NAMES = [
  ['First Pop!', 'Warm Up', 'Pop Squad', 'Easy Breezy', 'Balloon Bash', 'Bubble Fun', 'Quick Pop', 'Smooth Sailing', 'Pop Star', 'Party Time!'],
  ['Double Trouble', 'Speed Up!', 'Bomb Scare', 'Ghost Rush', 'Robot Rampage', 'Combo King', 'Gross Out', 'Wild Party', 'Frenzy!', 'Challenge Master'],
  ['Danger Ahead', 'Bomb Alley', 'Speed Demon', 'Ghost Army', 'Robot Fury', 'Toxic Zone', 'Nightmare', 'Inferno', 'Chaos!', 'Danger Master'],
  ['Pro Popper', 'Turbo Mode', 'Bomb Storm', 'Ghost Legion', 'Mech Wars', 'Extreme Combo', 'Toxic Rush', 'Blaze Runner', 'Total Mayhem', 'Expert Elite'],
  ['Ultimate Pop!', 'Legendary', 'God Mode', 'Final Boss', 'Pop God', 'Unstoppable', 'Infinity', 'Champion', 'Grand Master', 'POP MASTER'],
];

const WORLD_EMOJIS = [
  ['🎈', '🎊', '🤩', '😋', '🎪', '🫧', '🎪', '🥳', '🌟', '🎉'],
  ['🚀', '⚡', '💣', '👻', '🤖', '🔥', '🤢', '🎊', '🌪️', '🏆'],
  ['💀', '💣', '😈', '👻', '🤖', '☠️', '👾', '🔥', '🌪️', '☠️'],
  ['💪', '🚀', '💣', '👻', '🤖', '🔥', '☠️', '💨', '🌋', '👑'],
  ['🌟', '✨', '👑', '💀', '🏆', '💎', '♾️', '🥇', '🎖️', '🏅'],
];

const ALL_TYPES: BalloonType[] = ['silly', 'gross', 'ghost', 'robot', 'party'];

// ============================================================
// GENERATE 50 LEVELS
// ============================================================
function generateLevels(): LevelConfig[] {
  const levels: LevelConfig[] = [];

  for (let world = 1; world <= 5; world++) {
    const wIdx = world - 1;
    const worldData = WORLDS[wIdx];

    for (let lvl = 1; lvl <= 10; lvl++) {
      const id = (world - 1) * 10 + lvl; // 1-50
      const globalIdx = id - 1; // 0-49

      // GOAL: 100, 200, 300 ... 5000
      const goal = id * 100;

      // BALLOON TYPES — all 5 types available from level 1!
      const types: BalloonType[] = ['silly', 'gross', 'ghost', 'robot', 'party'];

      // SPAWN RATE: starts at 800ms, decreases per level (min 200ms)
      const spawnRate = Math.max(200, 800 - globalIdx * 12);

      // BALLOON SPEED: starts at 1.5, increases per level (max 5.0)
      const balloonSpeed = Math.min(5.0, 1.5 + globalIdx * 0.07);

      // MAX BALLOONS: starts at 8, increases per level (max 25)
      const maxBalloons = Math.min(25, 8 + Math.floor(globalIdx * 0.35));

      // BOMBS: introduced at level 4, increase over time
      const hasBombs = id >= 4;
      const bombChance = id < 4 ? 0 : Math.min(0.25, 0.04 + globalIdx * 0.004);

      // GOLDEN: introduced at level 2
      const hasGolden = id >= 2;
      const goldenChance = id < 2 ? 0 : Math.min(0.25, 0.08 + globalIdx * 0.003);

      // SLOW: introduced at level 4
      const hasSlow = id >= 4;
      const slowChance = id < 4 ? 0 : Math.min(0.12, 0.03 + globalIdx * 0.002);

      // SPEED: introduced at level 7
      const hasSpeed = id >= 7;
      const speedChance = id < 7 ? 0 : Math.min(0.15, 0.04 + globalIdx * 0.002);

      // GOAL TYPE variation
      let goalType: LevelGoalType = 'pop';
      if (id % 10 === 6) goalType = 'avoidBombs'; // level 6, 16, 26, 36, 46
      if (id % 10 === 9) goalType = 'scoreTarget'; // level 9, 19, 29, 39, 49

      // TIME THRESHOLDS for stars (seconds) — sqrt scaling so higher levels stay reasonable
      const baseTime = Math.round(Math.sqrt(goal) * 15);
      const threeStar = Math.round(baseTime * 0.45); // Fast
      const twoStar = Math.round(baseTime * 0.65);   // Medium
      const oneStar = Math.round(baseTime * 0.9);    // Slow but done

      // REWARDS
      const baseCoins = 40 + id * 8;
      const hasMysteryBox = id % 5 === 0; // every 5th level

      levels.push({
        id,
        name: WORLD_NAMES[wIdx][lvl - 1],
        description: goalType === 'scoreTarget'
          ? `Reach ${goal} points!`
          : goalType === 'avoidBombs'
            ? `Pop ${goal} balloons — avoid bombs!`
            : `Pop ${goal} balloons!`,
        emoji: WORLD_EMOJIS[wIdx][lvl - 1],
        world: world,
        worldName: worldData.name,
        goal,
        goalType,
        spawnRate,
        balloonSpeed: Math.round(balloonSpeed * 100) / 100,
        maxBalloons,
        balloonTypes: types,
        hasBombs,
        hasGolden,
        hasSlow,
        hasSpeed,
        bombChance: Math.round(bombChance * 1000) / 1000,
        goldenChance: Math.round(goldenChance * 1000) / 1000,
        slowChance: Math.round(slowChance * 1000) / 1000,
        speedChance: Math.round(speedChance * 1000) / 1000,
        starTimeThresholds: [oneStar, twoStar, threeStar] as [number, number, number],
        reward: { coins: baseCoins, mysteryBox: hasMysteryBox },
      });
    }
  }

  return levels;
}

export const LEVELS: LevelConfig[] = generateLevels();
export { WORLDS };

export function getLevel(id: number): LevelConfig | undefined {
  return LEVELS.find((l) => l.id === id);
}

/**
 * Calculate stars based on COMPLETION TIME (faster = more stars)
 * Always returns at least 1 star if level was completed.
 */
export function calculateStars(level: LevelConfig, completionTimeSec: number): number {
  if (completionTimeSec <= level.starTimeThresholds[2]) return 3;
  if (completionTimeSec <= level.starTimeThresholds[1]) return 2;
  return 1;
}

/**
 * Format seconds into mm:ss or just seconds
 */
export function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  if (m > 0) return `${m}:${s.toString().padStart(2, '0')}`;
  return `${s}s`;
}
