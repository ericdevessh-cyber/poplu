// Web Audio API Sound System for Poplu
// Generates all game sounds programmatically - no external files needed!

let audioCtx: AudioContext | null = null;

/**
 * Call this from a user gesture (click/tap) to unlock audio on mobile.
 * Must be called before any sound plays.
 */
export function initAudio(): void {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  } catch {
    // Audio not supported, silently ignore
  }
}

export function isAudioReady(): boolean {
  return !!audioCtx && audioCtx.state !== 'suspended';
}

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    audioCtx = new AudioContext();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

function playTone(
  frequency: number,
  duration: number,
  type: OscillatorType = 'sine',
  volume: number = 0.3,
  detune: number = 0
) {
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = type;
  osc.frequency.setValueAtTime(frequency, ctx.currentTime);
  osc.detune.setValueAtTime(detune, ctx.currentTime);

  gain.gain.setValueAtTime(Math.min(volume, 0.8), ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + duration);
}

function playNoise(duration: number, volume: number = 0.1) {
  const ctx = getAudioContext();
  const bufferSize = ctx.sampleRate * duration;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);

  for (let i = 0; i < bufferSize; i++) {
    data[i] = (Math.random() * 2 - 1) * volume;
  }

  const source = ctx.createBufferSource();
  source.buffer = buffer;

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(volume, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

  source.connect(gain);
  gain.connect(ctx.destination);

  source.start(ctx.currentTime);
}

// ============ BALLOON POP SOUNDS ============

export function playPopSound() {
  const ctx = getAudioContext();
  playTone(800, 0.1, 'sine', 0.4);
  playTone(1200, 0.08, 'sine', 0.3, 50);
  playNoise(0.05, 0.15);
}

export function playSillySound() {
  const ctx = getAudioContext();
  // Wobbly funny sound - quicker, bouncier
  playTone(600, 0.08, 'square', 0.3);
  setTimeout(() => playTone(900, 0.08, 'square', 0.3), 40);
  setTimeout(() => playTone(400, 0.12, 'square', 0.25), 80);
  setTimeout(() => playTone(1100, 0.1, 'square', 0.2), 120);
  setTimeout(() => playTone(700, 0.06, 'square', 0.15), 160);
 playNoise(0.1, 0.12);
}

export function playGrossSound() {
  const ctx = getAudioContext();
  // Squelchy gross sound - wet & slimy
  playTone(150, 0.25, 'sawtooth', 0.35);
  playTone(180, 0.2, 'sawtooth', 0.3, 30);
  playNoise(0.25, 0.18);
  // Bubbling
  setTimeout(() => playTone(200, 0.08, 'sine', 0.25), 80);
  setTimeout(() => playTone(260, 0.08, 'sine', 0.25), 130);
  setTimeout(() => playTone(180, 0.08, 'sine', 0.2), 180);
  setTimeout(() => playTone(300, 0.06, 'sine', 0.15), 230);
}

export function playGhostSound() {
  const ctx = getAudioContext();
  // Spooky-wooo sound with vibrato
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  const lfo = ctx.createOscillator();
  const lfoGain = ctx.createGain();

  // LFO for vibrato
  lfo.frequency.setValueAtTime(6, ctx.currentTime);
  lfoGain.gain.setValueAtTime(50, ctx.currentTime);
  lfo.connect(lfoGain);
  lfoGain.connect(osc.frequency);

  osc.type = 'sine';
  osc.frequency.setValueAtTime(800, ctx.currentTime);
  osc.frequency.linearRampToValueAtTime(350, ctx.currentTime + 0.5);

  gain.gain.setValueAtTime(0.4, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(ctx.currentTime);
  lfo.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.5);
  lfo.stop(ctx.currentTime + 0.5);

  // Wooo echo
  setTimeout(() => {
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(600, ctx.currentTime);
    osc2.frequency.linearRampToValueAtTime(250, ctx.currentTime + 0.35);
    gain2.gain.setValueAtTime(0.2, ctx.currentTime);
    gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(ctx.currentTime);
    osc2.stop(ctx.currentTime + 0.35);
  }, 200);
}

export function playRobotSound() {
  // Beep boop - more robotic, higher pitch
  playTone(523, 0.06, 'square', 0.35);
  setTimeout(() => playTone(659, 0.06, 'square', 0.35), 60);
  setTimeout(() => playTone(784, 0.06, 'square', 0.35), 120);
  setTimeout(() => playTone(1047, 0.1, 'square', 0.3), 180);
  setTimeout(() => playTone(784, 0.06, 'square', 0.2), 250);
  setTimeout(() => playTone(523, 0.08, 'square', 0.2), 310);
}

export function playPartySound() {
  // Festive ascending notes - brighter & louder
  const notes = [523, 587, 659, 698, 784, 880, 988, 1047];
  notes.forEach((freq, i) => {
    setTimeout(() => playTone(freq, 0.1, 'sine', 0.3), i * 35);
  });
  // Sparkle overlay
  setTimeout(() => playTone(2093, 0.08, 'sine', 0.15), 100);
  setTimeout(() => playTone(2637, 0.06, 'sine', 0.12), 200);
  playNoise(0.25, 0.12);
}

// ============ SPECIAL BALLOON SOUNDS ============

export function playGoldenSound() {
  // Sparkly shimmer
  playTone(1200, 0.15, 'sine', 0.3);
  playTone(1500, 0.12, 'sine', 0.25, 10);
  playTone(1800, 0.1, 'sine', 0.2, -10);
  setTimeout(() => playTone(2000, 0.15, 'sine', 0.2), 80);
  setTimeout(() => playTone(1600, 0.2, 'sine', 0.15), 160);
  playNoise(0.08, 0.1);
}

export function playBombSound() {
  // Explosion
  playNoise(0.4, 0.4);
  playTone(80, 0.3, 'sawtooth', 0.35);
  playTone(60, 0.4, 'sine', 0.3);
  // Debris
  setTimeout(() => playNoise(0.2, 0.15), 100);
}

export function playSlowMotionSound() {
  // Slow descending whoosh
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(1000, ctx.currentTime);
  osc.frequency.linearRampToValueAtTime(200, ctx.currentTime + 0.6);

  gain.gain.setValueAtTime(0.2, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.6);
}

export function playSpeedUpSound() {
  // Fast ascending whoosh
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(200, ctx.currentTime);
  osc.frequency.linearRampToValueAtTime(1500, ctx.currentTime + 0.3);

  gain.gain.setValueAtTime(0.15, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.3);
}

// ============ GAME EVENT SOUNDS ============

export function playLevelCompleteSound() {
  // Victory fanfare
  const notes = [523, 523, 523, 698, 880];
  const durations = [0.15, 0.15, 0.15, 0.2, 0.4];
  let time = 0;
  notes.forEach((freq, i) => {
    setTimeout(() => {
      playTone(freq, durations[i], 'sine', 0.3);
      playTone(freq * 1.5, durations[i], 'sine', 0.15);
    }, time);
    time += durations[i] * 800;
  });
}

export function playGameOverSound() {
  // Sad descending
  playTone(440, 0.2, 'sine', 0.3);
  setTimeout(() => playTone(370, 0.2, 'sine', 0.3), 200);
  setTimeout(() => playTone(311, 0.2, 'sine', 0.3), 400);
  setTimeout(() => playTone(262, 0.5, 'sine', 0.3), 600);
}

export function playCoinSound() {
  playTone(988, 0.08, 'sine', 0.2);
  setTimeout(() => playTone(1319, 0.12, 'sine', 0.2), 60);
}

export function playRewardSound() {
  // Exciting reward sound
  playTone(660, 0.1, 'sine', 0.25);
  setTimeout(() => playTone(880, 0.1, 'sine', 0.25), 80);
  setTimeout(() => playTone(1100, 0.15, 'sine', 0.25), 160);
  setTimeout(() => {
    playTone(1320, 0.2, 'sine', 0.3);
    playTone(660, 0.2, 'sine', 0.15);
  }, 240);
}

export function playMysteryBoxOpenSound() {
  // Magical opening
  const ctx = getAudioContext();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(300, ctx.currentTime);
  osc.frequency.linearRampToValueAtTime(1200, ctx.currentTime + 0.3);

  gain.gain.setValueAtTime(0.25, ctx.currentTime);
  gain.gain.setValueAtTime(0.25, ctx.currentTime + 0.2);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + 0.5);

  // Sparkle
  setTimeout(() => playTone(2000, 0.15, 'sine', 0.2), 200);
  setTimeout(() => playTone(2500, 0.1, 'sine', 0.15), 280);
  setTimeout(() => playTone(3000, 0.08, 'sine', 0.1), 340);
}

export function playClickSound() {
  playTone(600, 0.05, 'sine', 0.15);
}

export function playStarSound() {
  playTone(880, 0.1, 'sine', 0.2);
  setTimeout(() => playTone(1100, 0.1, 'sine', 0.2), 60);
  setTimeout(() => playTone(1320, 0.15, 'sine', 0.2), 120);
}

export function playUnlockSound() {
  playTone(440, 0.1, 'triangle', 0.2);
  setTimeout(() => playTone(554, 0.1, 'triangle', 0.2), 80);
  setTimeout(() => playTone(659, 0.1, 'triangle', 0.2), 160);
  setTimeout(() => playTone(880, 0.2, 'triangle', 0.25), 240);
}

export function playAlmostWinSound() {
  // Sad but hopeful
  playTone(440, 0.15, 'sine', 0.2);
  setTimeout(() => playTone(392, 0.15, 'sine', 0.2), 150);
  setTimeout(() => playTone(349, 0.3, 'sine', 0.2), 300);
}

export function playComboSound(combo: number) {
  // Increasing pitch based on combo
  const baseFreq = 400 + combo * 100;
  playTone(baseFreq, 0.08, 'sine', 0.25);
  setTimeout(() => playTone(baseFreq * 1.25, 0.08, 'sine', 0.2), 40);
}

// Map balloon types to their sounds
export function playBalloonPopSound(type: string) {
  switch (type) {
    case 'silly': playSillySound(); break;
    case 'gross': playGrossSound(); break;
    case 'ghost': playGhostSound(); break;
    case 'robot': playRobotSound(); break;
    case 'party': playPartySound(); break;
    case 'golden': playGoldenSound(); break;
    case 'bomb': playBombSound(); break;
    case 'slow': playSlowMotionSound(); break;
    case 'speed': playSpeedUpSound(); break;
    default: playPopSound();
  }
}
