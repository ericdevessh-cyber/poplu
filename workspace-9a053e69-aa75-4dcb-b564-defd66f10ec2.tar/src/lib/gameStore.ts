import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { LevelConfig, LEVELS, calculateStars } from './levels';

export type GameScreen =
  | 'home'
  | 'levelSelect'
  | 'playing'
  | 'paused'
  | 'levelComplete'
  | 'gameOver'
  | 'mysteryBox'
  | 'dailyReward'
  | 'shop'
  | 'settings';

export interface PopEffect {
  id: string;
  x: number;
  y: number;
  type: string;
  timestamp: number;
}

export interface FloatingText {
  id: string;
  x: number;
  y: number;
  text: string;
  color: string;
  timestamp: number;
}

export interface GameState {
  // Screen management
  screen: GameScreen;
  setScreen: (screen: GameScreen) => void;

  // Player data (persisted)
  coins: number;
  addCoins: (amount: number) => void;
  spendCoins: (amount: number) => boolean;

  unlockedLevels: number;
  unlockNextLevel: () => void;

  levelStars: Record<number, number>;
  setLevelStars: (levelId: number, stars: number) => void;

  highScores: Record<number, number>;
  setHighScore: (levelId: number, score: number) => void;

  totalPops: number;
  incrementTotalPops: () => void;

  selectedBalloonSkin: string;
  setSelectedBalloonSkin: (skin: string) => void;

  unlockedSkins: string[];
  unlockSkin: (skin: string) => void;

  soundEnabled: boolean;
  toggleSound: () => void;

  dailyRewardLastClaimed: string | null;
  setDailyRewardClaimed: (date: string) => void;
  dailyStreak: number;
  setDailyStreak: (streak: number) => void;

  // Game session state
  currentLevel: LevelConfig | null;
  setCurrentLevel: (level: LevelConfig) => void;

  score: number;
  addScore: (amount: number) => void;
  resetScore: () => void;

  lives: number;
  loseLife: () => void;
  resetLives: () => void;

  pops: number;
  incrementPops: () => void;
  resetPops: () => void;

  combo: number;
  incrementCombo: () => void;
  resetCombo: () => void;

  timeLeft: number;
  setTimeLeft: (time: number) => void;

  speedMultiplier: number;
  setSpeedMultiplier: (mult: number) => void;

  popEffects: PopEffect[];
  addPopEffect: (effect: PopEffect) => void;
  clearPopEffects: () => void;

  floatingTexts: FloatingText[];
  addFloatingText: (text: FloatingText) => void;
  clearFloatingTexts: () => void;

  // Game session - completion time
  completionTime: number; // seconds taken to complete the level

  // Game actions
  startLevel: (level: LevelConfig) => void;
  completeLevel: (completionTimeSec: number) => void;
  failLevel: () => void;
  resetGame: () => void;

  // Mystery box
  pendingMysteryBox: boolean;
  showMysteryBox: () => void;
  closeMysteryBox: () => void;
}

const DEFAULT_LIVES = 3;

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      // Screen
      screen: 'home' as GameScreen,
      setScreen: (screen) => set({ screen }),

      // Player data
      coins: 0,
      addCoins: (amount) => set((state) => ({ coins: state.coins + amount })),
      spendCoins: (amount) => {
        const state = get();
        if (state.coins >= amount) {
          set({ coins: state.coins - amount });
          return true;
        }
        return false;
      },

      unlockedLevels: 1,
      unlockNextLevel: () =>
        set((state) => ({
          unlockedLevels: Math.min(state.unlockedLevels + 1, LEVELS.length),
        })),

      levelStars: {},
      setLevelStars: (levelId, stars) =>
        set((state) => ({
          levelStars: {
            ...state.levelStars,
            [levelId]: Math.max(state.levelStars[levelId] || 0, stars),
          },
        })),

      highScores: {},
      setHighScore: (levelId, score) =>
        set((state) => ({
          highScores: {
            ...state.highScores,
            [levelId]: Math.max(state.highScores[levelId] || 0, score),
          },
        })),

      totalPops: 0,
      incrementTotalPops: () => set((state) => ({ totalPops: state.totalPops + 1 })),

      selectedBalloonSkin: 'default',
      setSelectedBalloonSkin: (skin) => set({ selectedBalloonSkin: skin }),

      unlockedSkins: ['default'],
      unlockSkin: (skin) =>
        set((state) => ({
          unlockedSkins: state.unlockedSkins.includes(skin)
            ? state.unlockedSkins
            : [...state.unlockedSkins, skin],
        })),

      soundEnabled: true,
      toggleSound: () => set((state) => ({ soundEnabled: !state.soundEnabled })),

      dailyRewardLastClaimed: null,
      setDailyRewardClaimed: (date) => set({ dailyRewardLastClaimed: date }),
      dailyStreak: 0,
      setDailyStreak: (streak) => set({ dailyStreak: streak }),

      // Game session
      currentLevel: null,
      setCurrentLevel: (level) => set({ currentLevel: level }),

      score: 0,
      addScore: (amount) => set((state) => ({ score: state.score + amount })),
      resetScore: () => set({ score: 0 }),

      lives: DEFAULT_LIVES,
      loseLife: () => set((state) => ({ lives: state.lives - 1 })),
      resetLives: () => set({ lives: DEFAULT_LIVES }),

      pops: 0,
      incrementPops: () => set((state) => ({ pops: state.pops + 1 })),
      resetPops: () => set({ pops: 0 }),

      combo: 0,
      incrementCombo: () => set((state) => ({ combo: state.combo + 1 })),
      resetCombo: () => set({ combo: 0 }),

      timeLeft: 0,
      setTimeLeft: (time) => set({ timeLeft: time }),

      speedMultiplier: 1,
      setSpeedMultiplier: (mult) => set({ speedMultiplier: mult }),

      popEffects: [],
      addPopEffect: (effect) =>
        set((state) => ({
          popEffects: [...state.popEffects.slice(-20), effect], // Keep last 20
        })),
      clearPopEffects: () => set({ popEffects: [] }),

      floatingTexts: [],
      addFloatingText: (text) =>
        set((state) => ({
          floatingTexts: [...state.floatingTexts.slice(-10), text],
        })),
      clearFloatingTexts: () => set({ floatingTexts: [] }),

      // Game actions
      completionTime: 0,

      startLevel: (level) => {
        set({
          screen: 'playing',
          currentLevel: level,
          score: 0,
          lives: DEFAULT_LIVES,
          pops: 0,
          combo: 0,
          timeLeft: level.timeLimit || 0,
          speedMultiplier: 1,
          completionTime: 0,
          popEffects: [],
          floatingTexts: [],
        });
      },

      completeLevel: (completionTimeSec: number) => {
        const state = get();
        const level = state.currentLevel;
        if (!level) return;

        // Stars based on COMPLETION TIME (faster = more stars)
        const stars = calculateStars(level, completionTimeSec);

        const prevStars = state.levelStars[level.id] || 0;
        set((s) => ({
          screen: 'levelComplete',
          completionTime: completionTimeSec,
          levelStars: {
            ...s.levelStars,
            [level.id]: Math.max(prevStars, stars),
          },
          highScores: {
            ...s.highScores,
            [level.id]: Math.max(s.highScores[level.id] || 0, s.score),
          },
          totalPops: s.totalPops + s.pops,
          coins: s.coins + level.reward.coins + (stars === 3 ? 20 : stars === 2 ? 10 : 0),
          unlockedLevels:
            level.id >= s.unlockedLevels
              ? Math.min(level.id + 1, LEVELS.length)
              : s.unlockedLevels,
          pendingMysteryBox: level.reward.mysteryBox || false,
        }));
      },

      failLevel: () => {
        const state = get();
        set({
          screen: 'gameOver',
          totalPops: state.totalPops + state.pops,
        });
      },

      resetGame: () => {
        set({
          screen: 'home',
          currentLevel: null,
          score: 0,
          lives: DEFAULT_LIVES,
          pops: 0,
          combo: 0,
          timeLeft: 0,
          speedMultiplier: 1,
          completionTime: 0,
          popEffects: [],
          floatingTexts: [],
        });
      },

      // Mystery box
      pendingMysteryBox: false,
      showMysteryBox: () => set({ screen: 'mysteryBox' }),
      closeMysteryBox: () => set({ pendingMysteryBox: false, screen: 'levelSelect' }),
    }),
    {
      name: 'poplu-game-storage',
      partialize: (state) => ({
        coins: state.coins,
        unlockedLevels: state.unlockedLevels,
        levelStars: state.levelStars,
        highScores: state.highScores,
        totalPops: state.totalPops,
        selectedBalloonSkin: state.selectedBalloonSkin,
        unlockedSkins: state.unlockedSkins,
        soundEnabled: state.soundEnabled,
        dailyRewardLastClaimed: state.dailyRewardLastClaimed,
        dailyStreak: state.dailyStreak,
      }),
    }
  )
);
