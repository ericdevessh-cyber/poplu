'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { useGameStore } from '@/lib/gameStore';
import HomeScreen from '@/components/screens/HomeScreen';
import LevelSelectScreen from '@/components/screens/LevelSelectScreen';
import GameScreen from '@/components/screens/GameScreen';
import LevelCompleteScreen from '@/components/screens/LevelCompleteScreen';
import GameOverScreen from '@/components/screens/GameOverScreen';
import MysteryBoxScreen from '@/components/screens/MysteryBoxScreen';
import DailyRewardScreen from '@/components/screens/DailyRewardScreen';
import ShopScreen from '@/components/screens/ShopScreen';

const pageTransition = {
  initial: { opacity: 0, scale: 0.95 },
  animate: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 1.02 },
  transition: { duration: 0.25, ease: 'easeOut' },
};

export default function Home() {
  const screen = useGameStore((s) => s.screen);

  return (
    <main className="relative h-[100dvh] w-screen overflow-hidden">
      <AnimatePresence mode="wait">
        {screen === 'home' && (
          <motion.div
            key="home"
            className="absolute inset-0"
            {...pageTransition}
          >
            <HomeScreen />
          </motion.div>
        )}

        {screen === 'levelSelect' && (
          <motion.div
            key="levelSelect"
            className="absolute inset-0"
            {...pageTransition}
          >
            <LevelSelectScreen />
          </motion.div>
        )}

        {screen === 'playing' && (
          <motion.div
            key="playing"
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <GameScreen />
          </motion.div>
        )}

        {screen === 'levelComplete' && (
          <motion.div
            key="levelComplete"
            className="absolute inset-0"
            {...pageTransition}
          >
            <LevelCompleteScreen />
          </motion.div>
        )}

        {screen === 'gameOver' && (
          <motion.div
            key="gameOver"
            className="absolute inset-0"
            {...pageTransition}
          >
            <GameOverScreen />
          </motion.div>
        )}

        {screen === 'mysteryBox' && (
          <motion.div
            key="mysteryBox"
            className="absolute inset-0"
            {...pageTransition}
          >
            <MysteryBoxScreen />
          </motion.div>
        )}

        {screen === 'dailyReward' && (
          <motion.div
            key="dailyReward"
            className="absolute inset-0"
            {...pageTransition}
          >
            <DailyRewardScreen />
          </motion.div>
        )}

        {screen === 'shop' && (
          <motion.div
            key="shop"
            className="absolute inset-0"
            {...pageTransition}
          >
            <ShopScreen />
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}
