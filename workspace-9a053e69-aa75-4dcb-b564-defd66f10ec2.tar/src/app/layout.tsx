import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Poplu - Pop the Talking Balloons! 🎈",
  description: "A fun, fast-paced kids arcade game! Pop colorful talking balloons, earn rewards, and unlock new levels!",
  keywords: ["Poplu", "kids game", "balloon pop", "arcade game", "fun for kids"],
  authors: [{ name: "Poplu Team" }],
  openGraph: {
    title: "Poplu - Pop the Talking Balloons! 🎈",
    description: "A fun kids arcade game with colorful talking balloons!",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#FF9800",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        style={{
          margin: 0,
          padding: 0,
          overflow: "hidden",
          position: "fixed",
          width: "100%",
          height: "100%",
          WebkitTapHighlightColor: "transparent",
          WebkitTouchCallout: "none",
          userSelect: "none",
        }}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
