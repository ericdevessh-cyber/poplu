'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Gift, Palette, Wand2, Coins, ChevronRight } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { playMysteryBoxOpenSound, playRewardSound, playCoinSound, playUnlockSound, playClickSound } from '@/lib/sounds';

// Available rewards
const COIN_REWARDS = [20, 30, 50, 100];
const RARE_SKINS = ['Rainbow Shine', 'Galaxy Swirl', 'Golden Glow', 'Diamond Frost'];
const SPECIAL_EFFECTS = ['Pop Confetti', 'Sparkle Trail', 'Heart Burst', 'Fireworks Pop'];

type RewardType = 'coins' | 'skin' | 'effect';

interface MysteryReward {
  type: RewardType;
  name: string;
  value?: number;
  icon: string;
}

// Sparkle particles for the background
const SPARKLE_COUNT = 25;

interface SparkleParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  delay: number;
  duration: number;
}

function generateSparkles(): SparkleParticle[] {
  return Array.from({ length: SPARKLE_COUNT }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 3 + Math.random() * 6,
    delay: Math.random() * 3,
    duration: 1.5 + Math.random() * 2,
  }));
}

function rollReward(): MysteryReward {
  const roll = Math.random() * 100;
  if (roll < 50) {
    // 50% coins
    const amount = COIN_REWARDS[Math.floor(Math.random() * COIN_REWARDS.length)];
    return { type: 'coins', name: `${amount} Coins`, value: amount, icon: '🪙' };
  } else if (roll < 75) {
    // 25% skin
    const skin = RARE_SKINS[Math.floor(Math.random() * RARE_SKINS.length)];
    return { type: 'skin', name: skin, icon: '🎨' };
  } else {
    // 25% effect
    const effect = SPECIAL_EFFECTS[Math.floor(Math.random() * SPECIAL_EFFECTS.length)];
    return { type: 'effect', name: effect, icon: '✨' };
  }
}

export default function MysteryBoxScreen() {
  const {
    soundEnabled,
    closeMysteryBox,
    addCoins,
    unlockSkin,
  } = useGameStore();

  const [sparkles] = useState<SparkleParticle[]>(generateSparkles);
  const [isOpen, setIsOpen] = useState(false);
  const [reward, setReward] = useState<MysteryReward | null>(null);
  const [showReward, setShowReward] = useState(false);
  const [coinParticles, setCoinParticles] = useState<number[]>([]);

  const handleOpenBox = useCallback(() => {
    if (isOpen) return;
    setIsOpen(true);

    if (soundEnabled) {
      playMysteryBoxOpenSound();
    }

    // After animation delay, reveal reward
    setTimeout(() => {
      const newReward = rollReward();
      setReward(newReward);

      // Apply reward
      if (newReward.type === 'coins' && newReward.value) {
        addCoins(newReward.value);
        // Coin rain
        setCoinParticles(Array.from({ length: 12 }, (_, i) => i));
        if (soundEnabled) {
          playCoinSound();
          setTimeout(() => playCoinSound(), 150);
          setTimeout(() => playCoinSound(), 300);
        }
      } else if (newReward.type === 'skin') {
        unlockSkin(newReward.name);
        if (soundEnabled) playUnlockSound();
      } else {
        if (soundEnabled) playRewardSound();
      }

      setShowReward(true);
    }, 1000);
  }, [isOpen, soundEnabled, addCoins, unlockSkin]);

  const handleContinue = useCallback(() => {
    if (soundEnabled) playClickSound();
    closeMysteryBox();
  }, [closeMysteryBox, soundEnabled]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Magical gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-600 via-fuchsia-500 to-pink-500" />

      {/* Animated sparkle particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {sparkles.map((s) => (
          <motion.div
            key={s.id}
            className="absolute rounded-full bg-white"
            style={{
              left: `${s.x}%`,
              top: `${s.y}%`,
              width: s.size,
              height: s.size,
            }}
            animate={{
              opacity: [0, 1, 0],
              scale: [0.5, 1.2, 0.5],
            }}
            transition={{
              duration: s.duration,
              delay: s.delay,
              repeat: Infinity,
              repeatDelay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center gap-6 px-4 py-8 max-w-md w-full">
        <AnimatePresence mode="wait">
          {!showReward ? (
            <motion.div
              key="box"
              className="flex flex-col items-center gap-6"
              initial={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.3 }}
            >
              {/* Title */}
              <motion.h2
                className="text-2xl sm:text-3xl font-black text-white/90 text-center drop-shadow-lg"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <Sparkles className="inline w-6 h-6 mr-1 text-yellow-300" />
                Mystery Box
                <Sparkles className="inline w-6 h-6 ml-1 text-yellow-300" />
              </motion.h2>

              {/* Box container */}
              <motion.div
                className="relative cursor-pointer"
                onClick={handleOpenBox}
                animate={
                  !isOpen
                    ? {
                        y: [0, -8, 0],
                        rotate: [0, -2, 2, -1, 0],
                      }
                    : {}
                }
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatDelay: 0.5,
                }}
                whileTap={{ scale: 0.95 }}
              >
                {/* Glow behind box */}
                <motion.div
                  className="absolute -inset-6 rounded-full bg-yellow-400/30 blur-xl"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                />

                {/* Box body */}
                <div className="relative w-36 h-32 sm:w-44 sm:h-40">
                  {/* Box base */}
                  <div className="absolute bottom-0 left-0 right-0 h-24 sm:h-30 bg-gradient-to-b from-fuchsia-500 to-purple-700 rounded-xl border-4 border-purple-400 shadow-2xl">
                    {/* Ribbon vertical */}
                    <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-5 bg-gradient-to-r from-yellow-400 to-amber-500" />
                    {/* Ribbon horizontal */}
                    <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 h-5 bg-gradient-to-b from-yellow-400 to-amber-500" />
                    {/* Center gem */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-yellow-300 rounded-full border-2 border-yellow-500 shadow-lg flex items-center justify-center z-10">
                      <span className="text-purple-800 font-black text-sm">?</span>
                    </div>
                  </div>

                  {/* Box lid */}
                  <motion.div
                    className="absolute top-0 left-0 right-0 h-12 sm:h-14 bg-gradient-to-b from-purple-400 to-fuchsia-500 rounded-t-xl border-4 border-purple-400 border-b-0 shadow-lg origin-bottom"
                    style={{ transformOrigin: 'bottom' }}
                    animate={
                      isOpen
                        ? { rotateX: -120, y: -10, opacity: 0.6 }
                        : { rotateX: 0, y: 0, opacity: 1 }
                    }
                    transition={{ duration: 0.6, ease: 'easeOut' }}
                  >
                    {/* Lid ribbon */}
                    <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-5 bg-gradient-to-r from-yellow-400 to-amber-500" />
                  </motion.div>

                  {/* Light from inside when opening */}
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-40 -z-10"
                        initial={{ opacity: 0, scale: 0.3 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.8, delay: 0.2 }}
                      >
                        <div className="w-full h-full bg-gradient-radial from-yellow-200/80 via-yellow-300/40 to-transparent rounded-full" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>

              {/* Tap to open text */}
              {!isOpen && (
                <motion.p
                  className="text-white text-lg font-bold"
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  ✨ Tap to Open! ✨
                </motion.p>
              )}

              {/* Opening... text */}
              {isOpen && !showReward && (
                <motion.p
                  className="text-yellow-200 text-lg font-bold"
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                >
                  Opening...
                </motion.p>
              )}
            </motion.div>
          ) : (
            /* Reward reveal */
            <motion.div
              key="reward"
              className="flex flex-col items-center gap-4"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ type: 'spring', stiffness: 200, damping: 12 }}
            >
              {/* Exciting text */}
              <motion.h2
                className="text-3xl sm:text-4xl font-black text-yellow-300 text-center drop-shadow-lg"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{
                  type: 'spring',
                  stiffness: 300,
                  damping: 10,
                  delay: 0.1,
                }}
              >
                {reward?.type === 'coins' ? 'Wow!' : 'Awesome!'}
              </motion.h2>

              {/* Reward icon */}
              <motion.div
                className="relative"
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{
                  type: 'spring',
                  stiffness: 200,
                  damping: 12,
                  delay: 0.3,
                }}
              >
                <motion.div
                  animate={{ scale: [1, 1.15, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="text-7xl sm:text-8xl drop-shadow-lg"
                >
                  {reward?.icon}
                </motion.div>

                {/* Glow behind icon */}
                <div className="absolute inset-0 -z-10 blur-2xl bg-yellow-300/40 rounded-full scale-150" />
              </motion.div>

              {/* Coin rain particles */}
              <div className="absolute inset-0 pointer-events-none overflow-hidden">
                {coinParticles.map((i) => (
                  <motion.div
                    key={i}
                    className="absolute text-xl"
                    style={{ left: `${10 + i * 7}%` }}
                    initial={{ top: '-5%', opacity: 1, rotate: 0 }}
                    animate={{
                      top: '105%',
                      opacity: [1, 1, 0.5],
                      rotate: [0, 360],
                      x: [0, (Math.random() - 0.5) * 60],
                    }}
                    transition={{
                      duration: 1.5 + Math.random() * 1,
                      delay: 0.5 + i * 0.08,
                      repeat: 1,
                    }}
                  >
                    🪙
                  </motion.div>
                ))}
              </div>

              {/* "You got" text */}
              <motion.p
                className="text-white/80 text-base font-medium"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                You got:
              </motion.p>

              {/* Reward name */}
              <motion.div
                className="bg-white/15 backdrop-blur-sm rounded-2xl px-6 py-3 border border-white/20 text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, type: 'spring', stiffness: 150 }}
              >
                <div className="flex items-center justify-center gap-2">
                  {reward?.type === 'coins' && (
                    <Coins className="w-5 h-5 text-yellow-400" />
                  )}
                  {reward?.type === 'skin' && (
                    <Palette className="w-5 h-5 text-pink-300" />
                  )}
                  {reward?.type === 'effect' && (
                    <Wand2 className="w-5 h-5 text-purple-300" />
                  )}
                  <span className="text-xl sm:text-2xl font-black text-white drop-shadow">
                    {reward?.name}
                  </span>
                </div>
                {reward?.type === 'skin' && (
                  <p className="text-pink-200/70 text-xs mt-1 font-medium">New Balloon Skin Unlocked!</p>
                )}
                {reward?.type === 'effect' && (
                  <p className="text-purple-200/70 text-xs mt-1 font-medium">New Special Effect!</p>
                )}
                {reward?.type === 'coins' && (
                  <p className="text-yellow-200/70 text-xs mt-1 font-medium">Added to your coins!</p>
                )}
              </motion.div>

              {/* Continue button */}
              <motion.button
                className="w-full max-w-xs min-h-[44px] py-3 px-6 rounded-2xl font-bold text-lg text-white bg-gradient-to-r from-fuchsia-500 to-purple-500 shadow-lg shadow-purple-500/30 flex items-center justify-center gap-2 mt-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1, type: 'spring', stiffness: 150 }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={handleContinue}
              >
                Continue
                <ChevronRight className="w-5 h-5" />
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
