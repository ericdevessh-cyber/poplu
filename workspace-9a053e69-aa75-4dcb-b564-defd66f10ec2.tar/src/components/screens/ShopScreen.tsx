'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Check, ShoppingCart } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { playCoinSound, playUnlockSound } from '@/lib/sounds';

// ─── Balloon skin definitions ────────────────────────────────────────────────
const BALLOON_SKINS = [
  {
    id: 'default',
    name: 'Default',
    emoji: '😜',
    price: 0,
    gradient: 'from-red-400 to-red-600',
    shadowColor: 'shadow-red-400/50',
    isFree: true,
  },
  {
    id: 'rainbow',
    name: 'Rainbow',
    emoji: '🌈',
    price: 50,
    gradient: 'from-red-400 via-yellow-400 to-green-400',
    shadowColor: 'shadow-yellow-400/50',
    isFree: false,
  },
  {
    id: 'galaxy',
    name: 'Galaxy',
    emoji: '🌌',
    price: 100,
    gradient: 'from-purple-500 via-indigo-600 to-slate-800',
    shadowColor: 'shadow-purple-500/50',
    isFree: false,
  },
  {
    id: 'fire',
    name: 'Fire',
    emoji: '🔥',
    price: 75,
    gradient: 'from-orange-400 via-red-500 to-red-700',
    shadowColor: 'shadow-orange-500/50',
    isFree: false,
  },
  {
    id: 'ice',
    name: 'Ice',
    emoji: '❄️',
    price: 75,
    gradient: 'from-cyan-300 via-sky-400 to-blue-500',
    shadowColor: 'shadow-cyan-300/50',
    isFree: false,
  },
  {
    id: 'golden',
    name: 'Golden',
    emoji: '👑',
    price: 150,
    gradient: 'from-yellow-300 via-amber-400 to-yellow-600',
    shadowColor: 'shadow-yellow-400/50',
    isFree: false,
  },
  {
    id: 'neon',
    name: 'Neon',
    emoji: '💚',
    price: 120,
    gradient: 'from-green-400 via-emerald-500 to-green-600',
    shadowColor: 'shadow-green-400/50',
    isFree: false,
  },
];

// ─── Effect definitions ──────────────────────────────────────────────────────
const EFFECTS = [
  {
    id: 'effect_pop_burst',
    name: 'Pop Burst',
    emoji: '✨',
    price: 30,
    description: 'Extra pop particles',
    gradient: 'from-yellow-300 to-orange-400',
  },
  {
    id: 'effect_screen_shake',
    name: 'Screen Shake',
    emoji: '📳',
    price: 40,
    description: 'Shake on pop',
    gradient: 'from-pink-400 to-red-400',
  },
  {
    id: 'effect_trail',
    name: 'Trail Effect',
    emoji: '🌟',
    price: 50,
    description: 'Balloons leave trails',
    gradient: 'from-amber-300 to-yellow-500',
  },
];

// ─── Animation variants ──────────────────────────────────────────────────────
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.06, delayChildren: 0.2 },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 300, damping: 20 },
  },
};

const tabUnderline = {
  active: { scaleX: 1, opacity: 1 },
  inactive: { scaleX: 0, opacity: 0 },
};

// ─── Balloon preview component ───────────────────────────────────────────────
function BalloonPreview({ gradient, emoji }: { gradient: string; emoji: string }) {
  return (
    <motion.div
      className={`relative mx-auto flex h-16 w-12 items-center justify-center rounded-[50%_50%_50%_50%/60%_60%_40%_40%] bg-gradient-to-b ${gradient} shadow-lg ${gradient.includes('red') ? 'shadow-red-400/40' : ''} ${gradient.includes('yellow') ? 'shadow-yellow-400/40' : ''} ${gradient.includes('purple') ? 'shadow-purple-400/40' : ''} ${gradient.includes('orange') ? 'shadow-orange-400/40' : ''} ${gradient.includes('cyan') || gradient.includes('sky') ? 'shadow-sky-400/40' : ''} ${gradient.includes('green') || gradient.includes('emerald') ? 'shadow-green-400/40' : ''} ${gradient.includes('amber') ? 'shadow-amber-400/40' : ''}`}
      whileHover={{ scale: 1.1, rotate: [-3, 3, -3, 0] }}
      transition={{ duration: 0.4 }}
    >
      {/* Balloon shine */}
      <div className="absolute left-2 top-2 h-3 w-2 rounded-full bg-white/40" />
      <span className="text-2xl">{emoji}</span>
      {/* Balloon knot */}
      <div className={`absolute -bottom-1.5 left-1/2 h-2.5 w-2.5 -translate-x-1/2 rotate-45 rounded-sm bg-gradient-to-b ${gradient}`} />
    </motion.div>
  );
}

// ─── Main ShopScreen ─────────────────────────────────────────────────────────
export default function ShopScreen() {
  const [activeTab, setActiveTab] = useState<'balloons' | 'effects'>('balloons');
  const {
    coins,
    selectedBalloonSkin,
    setSelectedBalloonSkin,
    unlockedSkins,
    unlockSkin,
    spendCoins,
    soundEnabled,
    setScreen,
  } = useGameStore();

  // ─── Buy skin handler ─────────────────────────────────────────────────
  const handleBuySkin = (skin: (typeof BALLOON_SKINS)[0]) => {
    if (unlockedSkins.includes(skin.id)) return;
    if (coins < skin.price) return;

    const success = spendCoins(skin.price);
    if (success) {
      unlockSkin(skin.id);
      setSelectedBalloonSkin(skin.id);
      if (soundEnabled) playCoinSound();
      if (soundEnabled) {
        setTimeout(() => playUnlockSound(), 150);
      }
    }
  };

  // ─── Equip skin handler ───────────────────────────────────────────────
  const handleEquipSkin = (skinId: string) => {
    setSelectedBalloonSkin(skinId);
    if (soundEnabled) playCoinSound();
  };

  // ─── Buy effect handler ───────────────────────────────────────────────
  const handleBuyEffect = (effect: (typeof EFFECTS)[0]) => {
    if (unlockedSkins.includes(effect.id)) return;
    if (coins < effect.price) return;

    const success = spendCoins(effect.price);
    if (success) {
      unlockSkin(effect.id);
      if (soundEnabled) playCoinSound();
      if (soundEnabled) {
        setTimeout(() => playUnlockSound(), 150);
      }
    }
  };

  return (
    <div className="flex min-h-dvh flex-col bg-gradient-to-b from-orange-200 via-amber-100 to-yellow-100">
      {/* ── Header ─────────────────────────────────────────────────────── */}
      <motion.header
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20 }}
        className="flex items-center justify-between px-4 py-3 sm:px-6"
      >
        {/* Back button */}
        <motion.button
          onClick={() => setScreen('home')}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-white/70 shadow-md backdrop-blur-sm"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <ArrowLeft className="h-6 w-6 text-orange-700" />
        </motion.button>

        {/* Title */}
        <div className="flex items-center gap-2">
          <span className="text-2xl">🛍️</span>
          <h1 className="text-2xl font-extrabold text-orange-800 sm:text-3xl">Shop</h1>
        </div>

        {/* Coins display */}
        <div className="flex items-center gap-2 rounded-full bg-white/70 px-4 py-2 shadow-md backdrop-blur-sm">
          <span className="text-xl">🪙</span>
          <motion.span
            key={coins}
            initial={{ scale: 1.3, color: '#f59e0b' }}
            animate={{ scale: 1, color: '#92400e' }}
            className="min-w-[2rem] text-center text-lg font-bold text-yellow-800 sm:text-xl"
          >
            {coins}
          </motion.span>
        </div>
      </motion.header>

      {/* ── Tabs ───────────────────────────────────────────────────────── */}
      <div className="mx-4 flex gap-1 rounded-2xl bg-white/50 p-1 backdrop-blur-sm sm:mx-6">
        {(['balloons', 'effects'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`relative flex h-12 flex-1 items-center justify-center gap-2 rounded-xl text-base font-bold capitalize transition-colors sm:text-lg ${
              activeTab === tab
                ? 'bg-white text-orange-700 shadow-md'
                : 'text-orange-500 hover:text-orange-600'
            }`}
          >
            <ShoppingCart className="h-5 w-5 sm:h-5 sm:w-5" />
            {tab === 'balloons' ? 'Balloons' : 'Effects'}
          </button>
        ))}
      </div>

      {/* ── Content area ───────────────────────────────────────────────── */}
      <div className="flex-1 overflow-y-auto px-4 pb-8 pt-4 sm:px-6">
        <AnimatePresence mode="wait">
          {activeTab === 'balloons' ? (
            <motion.div
              key="balloons"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4"
            >
              {BALLOON_SKINS.map((skin) => {
                const isOwned = unlockedSkins.includes(skin.id);
                const isEquipped = selectedBalloonSkin === skin.id;
                const canAfford = coins >= skin.price;

                return (
                  <motion.div
                    key={skin.id}
                    variants={cardVariants}
                    className={`relative flex flex-col items-center gap-2 rounded-2xl border-2 bg-white/80 p-4 shadow-md backdrop-blur-sm transition-all ${
                      isEquipped
                        ? 'border-orange-400 shadow-orange-200'
                        : 'border-white/60'
                    }`}
                    whileHover={{ y: -4 }}
                  >
                    {/* Equipped badge */}
                    {isEquipped && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-2 -right-2 flex h-7 w-7 items-center justify-center rounded-full bg-orange-500 shadow-lg"
                      >
                        <Check className="h-4 w-4 text-white" />
                      </motion.div>
                    )}

                    {/* Balloon preview */}
                    <BalloonPreview gradient={skin.gradient} emoji={skin.emoji} />

                    {/* Skin name */}
                    <span className="text-sm font-bold text-gray-800 sm:text-base">{skin.name}</span>

                    {/* Price / Status */}
                    {isOwned ? (
                      <span className="text-xs font-semibold text-green-600 sm:text-sm">
                        {isEquipped ? '✓ Equipped' : 'Owned'}
                      </span>
                    ) : (
                      <div className="flex items-center gap-1 text-sm font-bold text-yellow-700">
                        <span>🪙</span>
                        <span>{skin.price}</span>
                      </div>
                    )}

                    {/* Action button */}
                    {isOwned && !isEquipped ? (
                      <motion.button
                        onClick={() => handleEquipSkin(skin.id)}
                        className="mt-1 flex h-11 w-full items-center justify-center rounded-xl bg-gradient-to-r from-teal-400 to-cyan-500 text-sm font-bold text-white shadow-md sm:text-base"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Equip
                      </motion.button>
                    ) : !isOwned ? (
                      <motion.button
                        onClick={() => handleBuySkin(skin)}
                        className={`mt-1 flex h-11 w-full items-center justify-center rounded-xl text-sm font-bold text-white shadow-md sm:text-base ${
                          canAfford
                            ? 'bg-gradient-to-r from-green-400 to-emerald-500'
                            : 'cursor-not-allowed bg-gray-300'
                        }`}
                        whileHover={canAfford ? { scale: 1.05 } : {}}
                        whileTap={canAfford ? { scale: 0.95 } : {}}
                      >
                        Buy
                      </motion.button>
                    ) : null}
                  </motion.div>
                );
              })}
            </motion.div>
          ) : (
            <motion.div
              key="effects"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              exit={{ opacity: 0, x: 30 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4"
            >
              {EFFECTS.map((effect) => {
                const isOwned = unlockedSkins.includes(effect.id);
                const canAfford = coins >= effect.price;

                return (
                  <motion.div
                    key={effect.id}
                    variants={cardVariants}
                    className={`relative flex flex-col items-center gap-2 rounded-2xl border-2 bg-white/80 p-4 shadow-md backdrop-blur-sm transition-all ${
                      isOwned ? 'border-green-400 shadow-green-100' : 'border-white/60'
                    }`}
                    whileHover={{ y: -4 }}
                  >
                    {/* Owned badge */}
                    {isOwned && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-2 -right-2 flex h-7 w-7 items-center justify-center rounded-full bg-green-500 shadow-lg"
                      >
                        <Check className="h-4 w-4 text-white" />
                      </motion.div>
                    )}

                    {/* Effect icon */}
                    <motion.div
                      className={`flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${effect.gradient} shadow-lg`}
                      whileHover={{ scale: 1.1, rotate: [-5, 5, -5, 0] }}
                      transition={{ duration: 0.4 }}
                    >
                      <span className="text-3xl">{effect.emoji}</span>
                    </motion.div>

                    {/* Effect name */}
                    <span className="text-sm font-bold text-gray-800 sm:text-base">{effect.name}</span>

                    {/* Description */}
                    <span className="text-center text-xs text-gray-500 sm:text-sm">{effect.description}</span>

                    {/* Price / Status */}
                    {isOwned ? (
                      <span className="text-xs font-semibold text-green-600 sm:text-sm">✓ Unlocked</span>
                    ) : (
                      <div className="flex items-center gap-1 text-sm font-bold text-yellow-700">
                        <span>🪙</span>
                        <span>{effect.price}</span>
                      </div>
                    )}

                    {/* Action button */}
                    {!isOwned && (
                      <motion.button
                        onClick={() => handleBuyEffect(effect)}
                        className={`mt-1 flex h-11 w-full items-center justify-center rounded-xl text-sm font-bold text-white shadow-md sm:text-base ${
                          canAfford
                            ? 'bg-gradient-to-r from-green-400 to-emerald-500'
                            : 'cursor-not-allowed bg-gray-300'
                        }`}
                        whileHover={canAfford ? { scale: 1.05 } : {}}
                        whileTap={canAfford ? { scale: 0.95 } : {}}
                      >
                        Buy
                      </motion.button>
                    )}
                  </motion.div>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
