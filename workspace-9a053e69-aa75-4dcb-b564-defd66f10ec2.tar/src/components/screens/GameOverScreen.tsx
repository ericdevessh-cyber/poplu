'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { RotateCcw, LayoutGrid, Heart, XCircle } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { playGameOverSound, playClickSound } from '@/lib/sounds';

const ENCOURAGING_MESSAGES = [
  'Try again! You got this! 💪',
  'So close! One more try! 🔥',
  'You can do it! Don\'t give up! ⭐',
  'Every champion was once a beginner! 🌟',
  'Practice makes perfect! Keep popping! 🎈',
  'You\'re amazing! Give it another shot! 🚀',
];

export default function GameOverScreen() {
  const {
    currentLevel,
    score,
    soundEnabled,
    startLevel,
    setScreen,
  } = useGameStore();

  const [message] = useState(() =>
    ENCOURAGING_MESSAGES[Math.floor(Math.random() * ENCOURAGING_MESSAGES.length)]
  );

  const goal = currentLevel?.goal || 0;
  const goalType = currentLevel?.goalType || 'pop';
  const remaining = goal - score;

  // Play game over sound on mount
  useEffect(() => {
    if (soundEnabled) {
      playGameOverSound();
    }
  }, [soundEnabled]);

  const handleRetry = () => {
    if (soundEnabled) playClickSound();
    if (currentLevel) {
      startLevel(currentLevel);
    }
  };

  const handleLevels = () => {
    if (soundEnabled) playClickSound();
    setScreen('levelSelect');
  };

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Dark gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-slate-800 to-gray-900" />

      {/* Subtle animated circles in background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-red-500/5"
            style={{
              width: 100 + i * 60,
              height: 100 + i * 60,
              left: `${15 + i * 12}%`,
              top: `${20 + i * 8}%`,
            }}
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center gap-5 px-4 py-8 max-w-md w-full">
        {/* Sad emoji */}
        <motion.div
          className="text-6xl sm:text-7xl"
          animate={{
            y: [0, -12, 0],
            rotate: [0, -5, 5, -5, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatDelay: 1,
          }}
        >
          😭
        </motion.div>

        {/* "Game Over" title */}
        <motion.h1
          className="text-4xl sm:text-5xl font-black text-center bg-gradient-to-r from-red-400 via-orange-400 to-red-500 bg-clip-text text-transparent leading-tight"
          initial={{ scale: 0, y: -30 }}
          animate={{ scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 180, damping: 12, delay: 0.2 }}
        >
          Game Over
        </motion.h1>

        {/* Score card */}
        <motion.div
          className="bg-white/10 backdrop-blur-sm rounded-2xl px-6 py-4 flex flex-col items-center gap-1 border border-white/10"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <span className="text-gray-400 text-xs font-bold uppercase tracking-wider">Score Achieved</span>
          <div className="flex items-center gap-2">
            <XCircle className="w-6 h-6 text-red-400" />
            <span className="text-3xl font-black text-white">{score}</span>
          </div>
        </motion.div>

        {/* "Almost there" section */}
        <motion.div
          className="bg-white/5 backdrop-blur-sm rounded-2xl px-6 py-4 text-center border border-white/5"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <p className="text-orange-300 text-base sm:text-lg font-semibold">
            {goalType === 'timeAttack' || goalType === 'scoreTarget'
              ? `You needed ${remaining} more points! 😢`
              : `So close! You needed ${remaining} more pops 😢`}
          </p>
        </motion.div>

        {/* Encouraging message */}
        <motion.p
          className="text-gray-300 text-base sm:text-lg font-semibold text-center px-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          {message}
        </motion.p>

        {/* Action buttons */}
        <motion.div
          className="flex flex-col items-center gap-3 mt-3 w-full max-w-xs"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, type: 'spring', stiffness: 150 }}
        >
          {/* Try Again */}
          <motion.button
            className="w-full min-h-[44px] py-3 px-6 rounded-2xl font-bold text-lg text-white bg-gradient-to-r from-red-500 to-orange-500 shadow-lg shadow-red-500/30 flex items-center justify-center gap-2"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleRetry}
          >
            <RotateCcw className="w-5 h-5" />
            Try Again
          </motion.button>

          {/* Levels */}
          <motion.button
            className="w-full min-h-[44px] py-3 px-6 rounded-2xl font-bold text-lg text-gray-200 bg-gradient-to-r from-gray-500 to-gray-600 shadow-lg shadow-gray-600/20 flex items-center justify-center gap-2"
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleLevels}
          >
            <LayoutGrid className="w-5 h-5" />
            Levels
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
}
