'use client';

import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Coins, ArrowRight, RotateCcw, LayoutGrid, Gift, Sparkles, Clock, Trophy } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { calculateStars, getLevel, formatTime } from '@/lib/levels';
import { playStarSound, playLevelCompleteSound, playCoinSound, playClickSound } from '@/lib/sounds';

// Confetti particle data
const CONFETTI_COLORS = ['#FFD93D', '#FF6B6B', '#6BCB77', '#F472B6', '#FF9A3C', '#FBBF24', '#34D399', '#A78BFA'];
const CONFETTI_COUNT = 40;

interface ConfettiPiece {
  id: number;
  color: string;
  x: number;
  delay: number;
  size: number;
  rotationSpeed: number;
  swayAmount: number;
}

function generateConfetti(): ConfettiPiece[] {
  return Array.from({ length: CONFETTI_COUNT }, (_, i) => ({
    id: i,
    color: CONFETTI_COLORS[i % CONFETTI_COLORS.length],
    x: Math.random() * 100,
    delay: Math.random() * 2,
    size: 8 + Math.random() * 12,
    rotationSpeed: 180 + Math.random() * 360,
    swayAmount: 20 + Math.random() * 40,
  }));
}

export default function LevelCompleteScreen() {
  const {
    currentLevel,
    score,
    completionTime,
    pendingMysteryBox,
    soundEnabled,
    startLevel,
    setScreen,
  } = useGameStore();

  const [earnedStars, setEarnedStars] = useState(0);
  const [visibleStars, setVisibleStars] = useState(0);
  const [confetti] = useState<ConfettiPiece[]>(generateConfetti);

  // Stars calculated from COMPLETION TIME
  const stars = currentLevel ? calculateStars(currentLevel, completionTime) : 0;
  const levelReward = currentLevel?.reward.coins || 0;
  const starBonus = stars === 3 ? 20 : stars === 2 ? 10 : 0;
  const totalCoins = levelReward + starBonus;
  const nextLevel = currentLevel ? getLevel(currentLevel.id + 1) : null;

  // Time thresholds for display
  const timeFor3 = currentLevel?.starTimeThresholds[2] || 0;
  const timeFor2 = currentLevel?.starTimeThresholds[1] || 0;

  // Play level complete sound on mount
  useEffect(() => {
    if (soundEnabled) {
      playLevelCompleteSound();
    }
  }, [soundEnabled]);

  // Animate stars appearing one by one
  useEffect(() => {
    setEarnedStars(stars);
    if (stars === 0) return;

    const timers: NodeJS.Timeout[] = [];
    for (let i = 1; i <= stars; i++) {
      const timer = setTimeout(() => {
        setVisibleStars(i);
        if (soundEnabled) {
          playStarSound();
        }
      }, 600 + i * 500);
      timers.push(timer);
    }

    return () => timers.forEach(clearTimeout);
  }, [stars, soundEnabled]);

  const handleNextLevel = useCallback(() => {
    if (soundEnabled) playClickSound();
    if (nextLevel) {
      startLevel(nextLevel);
    } else {
      setScreen('levelSelect');
    }
  }, [nextLevel, startLevel, setScreen, soundEnabled]);

  const handleRetry = useCallback(() => {
    if (soundEnabled) playClickSound();
    if (currentLevel) {
      startLevel(currentLevel);
    }
  }, [currentLevel, startLevel, soundEnabled]);

  const handleLevels = useCallback(() => {
    if (soundEnabled) playClickSound();
    setScreen('levelSelect');
  }, [setScreen, soundEnabled]);

  const handleMysteryBox = useCallback(() => {
    if (soundEnabled) playClickSound();
    setScreen('mysteryBox');
  }, [setScreen, soundEnabled]);

  // Time-based messages
  const timeMessage = stars === 3
    ? '⚡ Lightning Fast!'
    : stars === 2
      ? '🔥 Great Speed!'
      : '✅ Level Complete!';

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-emerald-400 via-teal-400 to-cyan-300" />

      {/* Animated confetti */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {confetti.map((piece) => (
          <motion.div
            key={piece.id}
            className="absolute rounded-sm"
            style={{
              left: `${piece.x}%`,
              top: -20,
              width: piece.size,
              height: piece.size * 0.6,
              backgroundColor: piece.color,
            }}
            initial={{ y: -20, rotate: 0, opacity: 1 }}
            animate={{
              y: ['0vh', '110vh'],
              rotate: [0, piece.rotationSpeed],
              x: [0, piece.swayAmount, -piece.swayAmount / 2, piece.swayAmount / 3],
              opacity: [1, 1, 0.8, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              delay: piece.delay,
              repeat: Infinity,
              repeatDelay: Math.random() * 3,
              ease: 'linear',
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center gap-4 px-4 py-8 max-w-md w-full">
        {/* Level name */}
        <motion.div
          className="text-white text-lg font-bold drop-shadow-lg"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {currentLevel?.emoji} {currentLevel?.name}
        </motion.div>

        {/* "Level Complete!" title */}
        <motion.h1
          className="text-4xl sm:text-5xl font-black text-center bg-gradient-to-r from-yellow-300 via-rose-400 to-orange-400 bg-clip-text text-transparent drop-shadow-lg leading-tight"
          initial={{ scale: 0, rotate: -10 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 200, damping: 12, delay: 0.1 }}
        >
          🎉 Level Complete!
        </motion.h1>

        {/* Completion Time — BIG display */}
        <motion.div
          className="flex items-center gap-2 mt-1"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
        >
          <Clock className="w-6 h-6 sm:w-7 sm:h-7 text-white drop-shadow" />
          <span className="text-3xl sm:text-4xl font-black text-white drop-shadow-lg tabular-nums">
            {formatTime(completionTime)}
          </span>
        </motion.div>

        {/* Time-based message */}
        <motion.p
          className="text-white text-sm sm:text-base font-bold drop-shadow-md"
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          {timeMessage}
        </motion.p>

        {/* Star rating */}
        <motion.div
          className="flex gap-3 sm:gap-5 mt-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          {[1, 2, 3].map((starNum) => {
            const threshold = currentLevel?.starTimeThresholds[3 - starNum] || 0;
            const achieved = completionTime <= threshold;
            return (
              <div key={starNum} className="flex flex-col items-center gap-1">
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={
                    visibleStars >= starNum
                      ? { scale: 1, rotate: 0 }
                      : { scale: 0.6, rotate: 0 }
                  }
                  transition={
                    visibleStars >= starNum
                      ? {
                          type: 'spring',
                          stiffness: 300,
                          damping: 10,
                          delay: starNum * 0.05,
                        }
                      : {}
                  }
                >
                  {visibleStars >= starNum ? (
                    <motion.span
                      animate={{ scale: [1, 1.3, 1] }}
                      transition={{ duration: 0.4, repeat: 1 }}
                    >
                      <Star className="w-14 h-14 sm:w-16 sm:h-16 fill-yellow-400 text-yellow-400 drop-shadow-[0_2px_8px_rgba(251,191,36,0.6)]" />
                    </motion.span>
                  ) : (
                    <Star className="w-14 h-14 sm:w-16 sm:h-16 text-gray-400/40 stroke-gray-400/40" />
                  )}
                </motion.div>
                {/* Show time threshold under each star */}
                <motion.span
                  className="text-[10px] sm:text-xs font-semibold drop-shadow"
                  style={{ color: visibleStars >= starNum ? '#FDE68A' : 'rgba(255,255,255,0.5)' }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 + starNum * 0.15 }}
                >
                  ≤{formatTime(threshold)}
                </motion.span>
              </div>
            );
          })}
        </motion.div>

        {/* Score and coins */}
        <motion.div
          className="flex gap-4 mt-2"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          {/* Score */}
          <div className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-2xl px-4 py-3">
            <span className="text-yellow-200 text-xs font-bold uppercase tracking-wider">Score</span>
            <div className="flex items-center gap-1">
              <span className="text-xl">⭐</span>
              <span className="text-2xl font-black text-white drop-shadow">{score}</span>
            </div>
          </div>

          {/* Coins */}
          <motion.div
            className="flex flex-col items-center bg-white/20 backdrop-blur-sm rounded-2xl px-4 py-3"
            onHoverStart={() => { if (soundEnabled) playCoinSound(); }}
          >
            <span className="text-yellow-200 text-xs font-bold uppercase tracking-wider">Coins</span>
            <div className="flex items-center gap-1">
              <span className="text-xl">🪙</span>
              <span className="text-2xl font-black text-white drop-shadow">+{totalCoins}</span>
            </div>
          </motion.div>
        </motion.div>

        {/* Star bonus breakdown */}
        {starBonus > 0 && (
          <motion.p
            className="text-yellow-100/80 text-sm font-medium"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            +{levelReward} base + {starBonus} star bonus!
          </motion.p>
        )}

        {/* Time tips for improvement */}
        {stars < 3 && currentLevel && (
          <motion.div
            className="bg-white/15 backdrop-blur-sm rounded-xl px-4 py-2.5 mt-1"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
          >
            <div className="flex items-center gap-1.5 mb-1">
              <Trophy className="w-4 h-4 text-yellow-300" />
              <span className="text-white text-xs font-bold">Speed Tips</span>
            </div>
            {stars < 3 && (
              <p className="text-white/80 text-xs leading-relaxed">
                ⭐⭐⭐ under {formatTime(timeFor3)} • ⭐⭐ under {formatTime(timeFor2)}
              </p>
            )}
          </motion.div>
        )}

        {/* Action buttons */}
        <motion.div
          className="flex flex-col items-center gap-3 mt-3 w-full max-w-xs"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, type: 'spring', stiffness: 150 }}
        >
          {/* Next Level */}
          {nextLevel && (
            <motion.button
              className="w-full min-h-[44px] py-3 px-6 rounded-2xl font-bold text-lg text-white bg-gradient-to-r from-emerald-500 to-green-500 shadow-lg shadow-green-500/30 flex items-center justify-center gap-2"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={handleNextLevel}
            >
              Next Level
              <ArrowRight className="w-5 h-5" />
            </motion.button>
          )}

          {/* Mystery Box */}
          {pendingMysteryBox && (
            <motion.button
              className="w-full min-h-[44px] py-3 px-6 rounded-2xl font-bold text-lg text-white bg-gradient-to-r from-fuchsia-500 to-pink-500 shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={handleMysteryBox}
              animate={{
                boxShadow: [
                  '0 0 10px rgba(236,72,153,0.3)',
                  '0 0 25px rgba(236,72,153,0.6)',
                  '0 0 10px rgba(236,72,153,0.3)',
                ],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
              }}
            >
              <motion.span
                animate={{ rotate: [0, -3, 3, -3, 3, 0] }}
                transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
              >
                <Gift className="w-5 h-5" />
              </motion.span>
              Open Mystery Box!
              <Sparkles className="w-5 h-5" />
            </motion.button>
          )}

          {/* Retry and Levels */}
          <div className="flex gap-3 w-full">
            <motion.button
              className="flex-1 min-h-[44px] py-3 px-4 rounded-2xl font-bold text-base text-white bg-gradient-to-r from-yellow-400 to-amber-500 shadow-lg shadow-amber-400/20 flex items-center justify-center gap-2"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={handleRetry}
            >
              <RotateCcw className="w-4 h-4" />
              Retry
            </motion.button>

            <motion.button
              className="flex-1 min-h-[44px] py-3 px-4 rounded-2xl font-bold text-base text-white bg-gradient-to-r from-orange-400 to-orange-500 shadow-lg shadow-orange-400/20 flex items-center justify-center gap-2"
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={handleLevels}
            >
              <LayoutGrid className="w-4 h-4" />
              Levels
            </motion.button>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
