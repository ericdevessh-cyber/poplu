'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Lock, Trophy, ChevronDown, ChevronUp } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { LEVELS, WORLDS } from '@/lib/levels';
import { initAudio } from '@/lib/sounds';

const CARD_COLORS = [
  { bg: 'from-red-400 to-red-500', border: 'border-red-300' },
  { bg: 'from-orange-400 to-orange-500', border: 'border-orange-300' },
  { bg: 'from-yellow-400 to-amber-500', border: 'border-yellow-300' },
  { bg: 'from-green-400 to-emerald-500', border: 'border-green-300' },
  { bg: 'from-pink-400 to-pink-500', border: 'border-pink-300' },
  { bg: 'from-rose-400 to-rose-500', border: 'border-rose-300' },
  { bg: 'from-amber-400 to-amber-500', border: 'border-amber-300' },
  { bg: 'from-lime-400 to-green-500', border: 'border-lime-300' },
  { bg: 'from-fuchsia-400 to-fuchsia-500', border: 'border-fuchsia-300' },
  { bg: 'from-yellow-300 to-orange-500', border: 'border-yellow-300' },
];

const gridItemVariants = {
  hidden: { opacity: 0, scale: 0.8, y: 15 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 300, damping: 22 },
  },
};

function StarRating({ stars }: { stars: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3].map((s) => (
        <span
          key={s}
          className="text-sm"
          style={{ color: s <= stars ? '#FBBF24' : '#D1D5DB' }}
        >
          {s <= stars ? '★' : '☆'}
        </span>
      ))}
    </div>
  );
}

export default function LevelSelectScreen() {
  const {
    coins,
    unlockedLevels,
    levelStars,
    highScores,
    setScreen,
    startLevel,
  } = useGameStore();

  // Collapsed state per world
  const [collapsed, setCollapsed] = useState<Record<number, boolean>>({});

  const nextLevelId = unlockedLevels;

  const toggleWorld = (worldId: number) => {
    setCollapsed((prev) => ({ ...prev, [worldId]: !prev[worldId] }));
  };

  // Total stars
  const totalStars = Object.values(levelStars).reduce((a, b) => a + b, 0);
  const maxStars = unlockedLevels * 3;

  return (
    <div className="flex h-dvh flex-col overflow-hidden bg-gradient-to-b from-orange-400 via-rose-300 to-yellow-300">
      {/* Header */}
      <motion.header
        className="sticky top-0 z-20 flex items-center justify-between bg-white/70 px-4 py-3 shadow-sm backdrop-blur-md sm:px-6"
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 300, damping: 25 }}
      >
        <motion.button
          onClick={() => setScreen('home')}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-white/80 shadow-sm transition-colors hover:bg-white"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <ArrowLeft className="h-5 w-5 text-orange-600" />
        </motion.button>

        <div className="flex flex-col items-center">
          <h1 className="text-lg font-bold text-orange-800 sm:text-xl">Select Level</h1>
          <div className="flex items-center gap-1">
            <span className="text-xs text-orange-600">⭐ {totalStars}/{maxStars}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 rounded-full bg-white/60 px-3 py-1.5 shadow-sm backdrop-blur-sm">
          <span className="text-lg">🪙</span>
          <span className="text-base font-bold text-yellow-700">{coins}</span>
        </div>
      </motion.header>

      {/* Level Grid — scrollable */}
      <div className="flex-1 overflow-y-auto px-4 pb-8 pt-3 sm:px-6">
        {WORLDS.map((world) => {
          const worldLevels = LEVELS.filter((l) => l.world === world.id);
          const isCollapsed = collapsed[world.id];
          const hasUnlocked = worldLevels.some((l) => l.id <= unlockedLevels);

          return (
            <div key={world.id} className="mb-5">
              {/* World Header */}
              <motion.button
                className="flex w-full items-center gap-3 rounded-xl bg-white/40 px-4 py-3 backdrop-blur-sm"
                onClick={() => toggleWorld(world.id)}
                whileTap={{ scale: 0.98 }}
              >
                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-b ${world.color} text-xl shadow`}
                >
                  {world.emoji}
                </div>
                <div className="flex-1 text-left">
                  <h2 className="text-sm font-extrabold text-orange-900 sm:text-base">
                    World {world.id}: {world.name}
                  </h2>
                  <p className="text-xs text-orange-700/70">
                    Levels {world.id * 10 - 9}–{world.id * 10}
                    {!hasUnlocked && ' • 🔒 Locked'}
                  </p>
                </div>
                {hasUnlocked ? (
                  isCollapsed ? <ChevronDown className="h-5 w-5 text-orange-600" /> : <ChevronUp className="h-5 w-5 text-orange-600" />
                ) : (
                  <Lock className="h-5 w-5 text-orange-400" />
                )}
              </motion.button>

              {/* Levels Grid */}
              <AnimatePresence>
                {!isCollapsed && (
                  <motion.div
                    className="mt-2"
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25 }}
                  >
                    <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 md:grid-cols-5 sm:gap-3">
                      {worldLevels.map((level) => {
                        const isUnlocked = level.id <= unlockedLevels;
                        const stars = levelStars[level.id] || 0;
                        const highScore = highScores[level.id] || 0;
                        const isNextLevel = level.id === nextLevelId;
                        const colorScheme = CARD_COLORS[(level.id - 1) % CARD_COLORS.length];

                        return (
                          <motion.button
                            key={level.id}
                            variants={gridItemVariants}
                            initial="hidden"
                            animate="visible"
                            onClick={() => {
                              if (isUnlocked) {
                                initAudio();
                                startLevel(level);
                              }
                            }}
                            disabled={!isUnlocked}
                            className={`relative flex flex-col items-center gap-1 rounded-2xl border-2 p-2.5 sm:p-3 transition-all ${
                              isUnlocked
                                ? `bg-gradient-to-b ${colorScheme.bg} ${colorScheme.border} cursor-pointer hover:scale-105 active:scale-95`
                                : 'border-gray-300 bg-gray-200/60 cursor-not-allowed opacity-60'
                            } ${isNextLevel ? 'ring-2 ring-yellow-400 ring-offset-2' : ''}`}
                            style={
                              isNextLevel
                                ? { animation: 'pulseGlow 2s ease-in-out infinite' }
                                : undefined
                            }
                          >
                            {/* NEW badge */}
                            {isNextLevel && isUnlocked && (
                              <motion.div
                                className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-yellow-400 text-[9px] font-bold text-yellow-900 shadow"
                                animate={{ scale: [1, 1.2, 1] }}
                                transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                              >
                                NEW
                              </motion.div>
                            )}

                            {/* Level Number */}
                            <div
                              className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-extrabold ${
                                isUnlocked ? 'bg-white/90 text-orange-700' : 'bg-gray-300 text-gray-500'
                              }`}
                              style={{ boxShadow: '0 2px 6px rgba(0,0,0,0.15)' }}
                            >
                              {level.id}
                            </div>

                            {/* Emoji */}
                            <span className="text-2xl sm:text-3xl" role="img">
                              {isUnlocked ? level.emoji : '🔒'}
                            </span>

                            {/* Name */}
                            <span
                              className={`text-center text-[10px] font-bold leading-tight sm:text-xs ${
                                isUnlocked ? 'text-white' : 'text-gray-400'
                              }`}
                              style={{ textShadow: isUnlocked ? '0 1px 3px rgba(0,0,0,0.2)' : 'none' }}
                            >
                              {level.name}
                            </span>

                            {/* Goal */}
                            {isUnlocked && (
                              <span className="text-[9px] font-semibold text-white/80">
                                {level.goalType === 'scoreTarget' ? `🏆 ${level.goal}pts` : `🎈 ${level.goal}`}
                              </span>
                            )}

                            {/* Stars */}
                            {isUnlocked && <StarRating stars={stars} />}

                            {/* High Score */}
                            {isUnlocked && highScore > 0 && (
                              <div className="flex items-center gap-0.5">
                                <Trophy className="h-2.5 w-2.5 text-yellow-200" />
                                <span className="text-[10px] font-semibold text-white/90">{highScore}</span>
                              </div>
                            )}

                            {/* Lock Overlay */}
                            {!isUnlocked && (
                              <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-black/20 backdrop-blur-[1px]">
                                <Lock className="h-5 w-5 text-gray-400" />
                              </div>
                            )}
                          </motion.button>
                        );
                      })}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>

      {/* Pulse glow keyframes */}
      <style jsx>{`
        @keyframes pulseGlow {
          0%, 100% {
            box-shadow: 0 0 8px rgba(251, 191, 36, 0.4), 0 0 20px rgba(251, 191, 36, 0.2);
          }
          50% {
            box-shadow: 0 0 16px rgba(251, 191, 36, 0.7), 0 0 35px rgba(251, 191, 36, 0.4);
          }
        }
      `}</style>
    </div>
  );
}
