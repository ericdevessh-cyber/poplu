'use client';

import { motion } from 'framer-motion';
import { Settings, ShoppingCart } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { BALLOON_CONFIG } from '@/lib/levels';
import { initAudio, playClickSound } from '@/lib/sounds';

const TITLE_COLORS = ['#EF4444', '#F97316', '#EAB308', '#22C55E', '#EC4899'];
const TITLE_LETTERS = ['P', 'O', 'P', 'L', 'U'];

const FLOATING_BALLOONS = [
  { emoji: BALLOON_CONFIG.silly.emoji, left: '8%', size: '2.5rem', delay: 0, duration: 8 },
  { emoji: BALLOON_CONFIG.gross.emoji, left: '22%', size: '2rem', delay: 1.5, duration: 10 },
  { emoji: BALLOON_CONFIG.ghost.emoji, left: '78%', size: '2.2rem', delay: 3, duration: 9 },
  { emoji: BALLOON_CONFIG.robot.emoji, left: '88%', size: '2.8rem', delay: 0.8, duration: 7.5 },
  { emoji: BALLOON_CONFIG.party.emoji, left: '45%', size: '2rem', delay: 2, duration: 11 },
  { emoji: BALLOON_CONFIG.golden.emoji, left: '62%', size: '1.8rem', delay: 4, duration: 8.5 },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.3,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { type: 'spring', stiffness: 260, damping: 20 },
  },
};

const letterVariants = {
  hidden: { opacity: 0, scale: 0, rotate: -20 },
  visible: (i: number) => ({
    opacity: 1,
    scale: 1,
    rotate: 0,
    transition: {
      type: 'spring',
      stiffness: 300,
      damping: 15,
      delay: 0.4 + i * 0.1,
    },
  }),
};

const bounceLoop = {
  y: [0, -12, 0],
  transition: {
    duration: 1.2,
    repeat: Infinity,
    repeatType: 'loop' as const,
    ease: 'easeInOut',
  },
};

export default function HomeScreen() {
  const { coins, soundEnabled, setScreen, toggleSound } = useGameStore();

  const handlePlay = () => {
    initAudio(); // Unlock audio on user gesture (required for mobile)
    if (soundEnabled) playClickSound();
    setScreen('levelSelect');
  };

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-gradient-to-b from-orange-300 via-yellow-200 to-pink-300">
      {/* Floating Balloons Background */}
      {FLOATING_BALLOONS.map((balloon, i) => (
        <div
          key={i}
          className="pointer-events-none absolute bottom-0"
          style={{
            left: balloon.left,
            fontSize: balloon.size,
            animation: `floatUp ${balloon.duration}s ease-in-out ${balloon.delay}s infinite`,
            opacity: 0.6,
          }}
        >
          {balloon.emoji}
        </div>
      ))}

      <style jsx>{`
        @keyframes floatUp {
          0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 0.6;
          }
          90% {
            opacity: 0.6;
          }
          100% {
            transform: translateY(-20vh) rotate(15deg);
            opacity: 0;
          }
        }
        @keyframes pulse-glow {
          0%, 100% {
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.4), 0 0 40px rgba(249, 115, 22, 0.2);
          }
          50% {
            box-shadow: 0 0 30px rgba(239, 68, 68, 0.6), 0 0 60px rgba(249, 115, 22, 0.3);
          }
        }
      `}</style>

      {/* Main Content */}
      <motion.div
        className="relative z-10 flex flex-col items-center gap-6 px-4 py-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Title */}
        <motion.div className="flex items-center gap-1 sm:gap-2" variants={itemVariants}>
          {TITLE_LETTERS.map((letter, i) => (
            <motion.span
              key={i}
              custom={i}
              variants={letterVariants}
              animate={{
                ...bounceLoop.y !== undefined ? { y: [0, -(8 + i * 2), 0] } : {},
              }}
              transition={{
                duration: 1.2,
                repeat: Infinity,
                repeatType: 'loop',
                ease: 'easeInOut',
                delay: i * 0.15,
              }}
              className="text-7xl font-black sm:text-8xl md:text-9xl"
              style={{
                color: TITLE_COLORS[i],
                textShadow: `3px 3px 0 rgba(0,0,0,0.15), 0 0 20px ${TITLE_COLORS[i]}40`,
              }}
            >
              {letter}
            </motion.span>
          ))}
        </motion.div>

        {/* Subtitle */}
        <motion.p
          variants={itemVariants}
          className="text-lg font-semibold text-orange-800 sm:text-xl md:text-2xl"
          style={{ textShadow: '0 1px 2px rgba(0,0,0,0.1)' }}
        >
          Pop the Talking Balloons!
        </motion.p>

        {/* Decorative emoji row */}
        <motion.div variants={itemVariants} className="flex gap-3 text-3xl sm:text-4xl">
          <span>{BALLOON_CONFIG.silly.emoji}</span>
          <span>{BALLOON_CONFIG.gross.emoji}</span>
          <span>{BALLOON_CONFIG.ghost.emoji}</span>
          <span>{BALLOON_CONFIG.robot.emoji}</span>
          <span>{BALLOON_CONFIG.party.emoji}</span>
        </motion.div>

        {/* Play Button */}
        <motion.div variants={itemVariants} className="mt-4">
          <motion.button
            onClick={handlePlay}
            className="flex h-[72px] min-w-[200px] items-center justify-center rounded-full border-4 border-red-400 bg-gradient-to-b from-red-400 via-orange-400 to-yellow-400 px-10 text-3xl font-extrabold text-white shadow-lg"
            style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.3)' }}
            whileHover={{ scale: 1.1, rotate: [-2, 2, -2, 0] }}
            whileTap={{ scale: 0.95 }}
            animate={{
              boxShadow: [
                '0 4px 20px rgba(239, 68, 68, 0.4), inset 0 -3px 6px rgba(0,0,0,0.1)',
                '0 8px 30px rgba(249, 115, 22, 0.5), inset 0 -3px 6px rgba(0,0,0,0.1)',
                '0 4px 20px rgba(239, 68, 68, 0.4), inset 0 -3px 6px rgba(0,0,0,0.1)',
              ],
            }}
            transition={{
              boxShadow: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
            }}
          >
            PLAY
          </motion.button>
        </motion.div>

        {/* Bottom Row: Coins, Settings, Shop */}
        <motion.div
          variants={itemVariants}
          className="mt-6 flex items-center gap-5"
        >
          {/* Coins */}
          <div className="flex items-center gap-2 rounded-full bg-white/50 px-5 py-2.5 shadow-sm backdrop-blur-sm">
            <span className="text-2xl">🪙</span>
            <span className="min-w-[2rem] text-center text-xl font-bold text-yellow-700">
              {coins}
            </span>
          </div>

          {/* Settings Button */}
          <motion.button
            onClick={toggleSound}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-white/60 shadow-sm backdrop-blur-sm transition-colors hover:bg-white/80"
            whileHover={{ scale: 1.1, rotate: 90 }}
            whileTap={{ scale: 0.9 }}
            title={soundEnabled ? 'Mute sounds' : 'Unmute sounds'}
          >
            {soundEnabled ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-orange-600"
              >
                <path d="M12 2v20" />
                <path d="M2 8h4l6-6v24l-6-6H2a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2z" />
                <path d="M2 8v4a2 2 0 0 0 2 2h4l6 6" />
                <path d="M18 8l4 4-4 4" />
                <path d="M18 12h-6" />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-gray-400"
              >
                <path d="M12 2v20" />
                <path d="M2 8h4l6-6v24l-6-6H2a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2z" />
                <line x1="1" y1="1" x2="23" y2="23" />
              </svg>
            )}
          </motion.button>

          {/* Shop Button */}
          <motion.button
            onClick={() => setScreen('shop')}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-white/60 shadow-sm backdrop-blur-sm transition-colors hover:bg-white/80"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            title="Shop"
          >
            <ShoppingCart className="h-6 w-6 text-orange-600" />
          </motion.button>
        </motion.div>
      </motion.div>
    </div>
  );
}
