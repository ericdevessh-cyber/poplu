'use client';

import { useRef, useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, Clock, Zap } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import {
  BalloonType,
  SpecialBalloonType,
} from '@/lib/levels';
import {
  playBalloonPopSound,
  playBombSound,
  playComboSound,
} from '@/lib/sounds';
import Balloon from '@/components/game/Balloon';
import PopEffect from '@/components/game/PopEffect';
import FloatingText from '@/components/game/FloatingText';

// ---------- types ----------

interface ActiveBalloon {
  id: string;
  type: BalloonType | SpecialBalloonType;
  x: number;
  y: number;
  speed: number;
}

// ---------- main component ----------

export default function GameScreen() {
  // ---- store ----
  const currentLevel = useGameStore((s) => s.currentLevel);
  const score = useGameStore((s) => s.score);
  const lives = useGameStore((s) => s.lives);
  const pops = useGameStore((s) => s.pops);
  const combo = useGameStore((s) => s.combo);
  const timeLeft = useGameStore((s) => s.timeLeft);
  const powerUpMult = useGameStore((s) => s.speedMultiplier);
  const soundEnabled = useGameStore((s) => s.soundEnabled);

  const addScore = useGameStore((s) => s.addScore);
  const incrementPops = useGameStore((s) => s.incrementPops);
  const incrementCombo = useGameStore((s) => s.incrementCombo);
  const resetCombo = useGameStore((s) => s.resetCombo);
  const loseLife = useGameStore((s) => s.loseLife);
  const setTimeLeft = useGameStore((s) => s.setTimeLeft);
  const setSpeedMultiplier = useGameStore((s) => s.setSpeedMultiplier);
  const clearPopEffects = useGameStore((s) => s.clearPopEffects);
  const clearFloatingTexts = useGameStore((s) => s.clearFloatingTexts);
  const completeLevel = useGameStore((s) => s.completeLevel);
  const failLevel = useGameStore((s) => s.failLevel);
  const setScreen = useGameStore((s) => s.setScreen);

  // ---- local state ----
  const [activeBalloons, setActiveBalloons] = useState<ActiveBalloon[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const [localEffects, setLocalEffects] = useState<
    Array<{ id: string; type: string; x: number; y: number; timestamp: number }>
  >([]);
  const [localTexts, setLocalTexts] = useState<
    Array<{ id: string; x: number; y: number; text: string; color: string; timestamp: number }>
  >([]);
  // Time-based speed: track elapsed time (updates every 500ms for faster response)
  const [elapsedMs, setElapsedMs] = useState(0);
  // Visual feedback for life loss
  const [screenFlash, setScreenFlash] = useState(false);

  // ---- refs ----
  const gameAreaRef = useRef<HTMLDivElement>(null);
  const spawnIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const timerIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const elapsedTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const speedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const level = currentLevel;

  // ================================================================
  // TIME-BASED SPEED BONUS — AGGRESSIVE & NOTICEABLE
  // Speed increases 3% per second with steps every 5 seconds
  // 0s: 1.0x, 5s: 1.15x, 10s: 1.30x, 15s: 1.45x, 20s: 1.60x, 30s: 1.90x
  // ================================================================
  const timeSpeedBonus = 1 + (elapsedMs / 1000) * 0.03;
  // effective = power-up mult (slow/speed balloon) × time bonus
  const effectiveSpeedMultiplier = powerUpMult * timeSpeedBonus;

  // ================================================================
  // BALLOON TYPE SELECTION
  // ================================================================
  const pickBalloonType = useCallback((): BalloonType | SpecialBalloonType => {
    if (!level) return 'silly';

    const rand = Math.random();

    if (level.hasSpeed && rand < level.speedChance) return 'speed';
    if (level.hasSlow && rand < level.speedChance + level.slowChance) return 'slow';
    if (level.hasBombs && rand < level.speedChance + level.slowChance + level.bombChance) return 'bomb';
    if (level.hasGolden && rand < level.speedChance + level.slowChance + level.bombChance + level.goldenChance)
      return 'golden';

    const types = level.balloonTypes;
    return types[Math.floor(Math.random() * types.length)];
  }, [level]);

  // ================================================================
  // SPAWN BALLOON
  // ================================================================
  const spawnBalloon = useCallback(() => {
    if (!level || !gameAreaRef.current || isPaused) return;

    const areaWidth = gameAreaRef.current.clientWidth;
    const areaHeight = gameAreaRef.current.clientHeight;

    setActiveBalloons((prev) => {
      if (prev.length >= level.maxBalloons) return prev;

      const type = pickBalloonType();
      const balloonWidth = window.innerWidth < 768 ? 70 : 90;
      const padding = 20;
      const x = padding + Math.random() * (areaWidth - balloonWidth - padding * 2);
      const y = areaHeight + 20;

      const newBalloon: ActiveBalloon = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
        type,
        x,
        y,
        speed: level.balloonSpeed + (Math.random() * 0.6 - 0.3),
      };

      return [...prev, newBalloon];
    });
  }, [level, isPaused, pickBalloonType]);

  // ================================================================
  // HELPERS — add floating text
  // ================================================================
  const addText = useCallback((x: number, y: number, text: string, color: string) => {
    const id = `ft-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setLocalTexts((prev) => [...prev, { id, x, y, text, color, timestamp: Date.now() }]);
    setTimeout(() => setLocalTexts((prev) => prev.filter((t) => t.id !== id)), 1300);
  }, []);

  // ================================================================
  // HANDLERS
  // ================================================================
  const handlePop = useCallback(
    (id: string, type: string, x: number, y: number) => {
      if (!level) return;

      setActiveBalloons((prev) => prev.filter((b) => b.id !== id));

      if (soundEnabled) {
        if (type === 'bomb') playBombSound();
        else playBalloonPopSound(type);
      }

      // pop effect
      const effectId = `pe-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setLocalEffects((prev) => [...prev, { id: effectId, type, x, y, timestamp: Date.now() }]);
      setTimeout(() => setLocalEffects((prev) => prev.filter((e) => e.id !== effectId)), 700);

      // ---- BOMB ----
      if (type === 'bomb') {
        loseLife();
        addText(x, y, '💣 BOOM!', '#EF4444');
        if (useGameStore.getState().lives <= 0) {
          setTimeout(() => failLevel(), 400);
        }
        return;
      }

      // ---- NORMAL POP ----
      const points = type === 'golden' ? 5 : 1;
      addScore(points);
      incrementPops();
      incrementCombo();

      const ftColor =
        type === 'golden' ? '#FBBF24'
        : type === 'slow' ? '#60A5FA'
        : type === 'speed' ? '#EF4444'
        : '#FFFFFF';

      const currentCombo = useGameStore.getState().combo;
      const ftText = currentCombo > 2 ? `COMBO x${currentCombo}!` : `+${points}`;
      addText(x, y, ftText, ftColor);

      if (currentCombo > 2 && soundEnabled) playComboSound(currentCombo);

      // ---- SLOW power-up ----
      if (type === 'slow') {
        setSpeedMultiplier(0.5);
        if (speedTimerRef.current) clearTimeout(speedTimerRef.current);
        speedTimerRef.current = setTimeout(() => {
          setSpeedMultiplier(1);
          speedTimerRef.current = null;
        }, 3000);
      }

      // ---- SPEED power-up ----
      if (type === 'speed') {
        setSpeedMultiplier(2);
        if (speedTimerRef.current) clearTimeout(speedTimerRef.current);
        speedTimerRef.current = setTimeout(() => {
          setSpeedMultiplier(1);
          speedTimerRef.current = null;
        }, 3000);
      }

      // check goal — pass elapsed time for star calculation
      const cs = useGameStore.getState();
      const timeSec = elapsedMs / 1000;
      if (level.goalType === 'pop' && cs.pops >= level.goal) setTimeout(() => completeLevel(timeSec), 300);
      if (level.goalType === 'scoreTarget' && cs.score >= level.goal) setTimeout(() => completeLevel(timeSec), 300);
      if (level.goalType === 'avoidBombs' && cs.pops >= level.goal) setTimeout(() => completeLevel(timeSec), 300);
    },
    [level, soundEnabled, elapsedMs, addScore, incrementPops, incrementCombo, loseLife, failLevel, setSpeedMultiplier, completeLevel, addText],
  );

  // ================================================================
  // BALLOON MISSED (touched top of screen) → LOSE A LIFE
  // ================================================================
  const handleMiss = useCallback(
    (id: string) => {
      setActiveBalloons((prev) => prev.filter((b) => b.id !== id));
      resetCombo();

      // Lose a life!
      loseLife();

      // Screen flash red!
      setScreenFlash(true);
      setTimeout(() => setScreenFlash(false), 400);

      // Show "MISSED!" at top-center of screen
      addText(
        window.innerWidth / 2 - 50,
        90,
        '💔 -1 ❤️',
        '#EF4444',
      );

      // Check game over
      if (useGameStore.getState().lives <= 0) {
        setTimeout(() => failLevel(), 400);
      }
    },
    [resetCombo, loseLife, failLevel, addText],
  );

  const handleEffectComplete = useCallback((id: string) => {
    setLocalEffects((prev) => prev.filter((e) => e.id !== id));
  }, []);

  const handleTextComplete = useCallback((id: string) => {
    setLocalTexts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // ================================================================
  // SPAWN INTERVAL
  // ================================================================
  useEffect(() => {
    if (!level || isPaused) return;

    spawnBalloon();
    spawnIntervalRef.current = setInterval(spawnBalloon, level.spawnRate);

    return () => {
      if (spawnIntervalRef.current) {
        clearInterval(spawnIntervalRef.current);
        spawnIntervalRef.current = null;
      }
    };
  }, [level, isPaused, spawnBalloon]);

  // ================================================================
  // ELAPSED TIME TRACKER (for speed increase) — updates every 500ms
  // ================================================================
  useEffect(() => {
    if (!level || isPaused) return;

    elapsedTimerRef.current = setInterval(() => {
      setElapsedMs((prev) => {
        const next = prev + 500;
        // Check if we crossed a speed-up threshold (every 15% = every ~5 seconds)
        const newBonus = 1 + (next / 1000) * 0.03;
        const newPercent = Math.round((newBonus - 1) * 100);
        const newStep = Math.floor(newPercent / 15);
        const oldBonus = 1 + (prev / 1000) * 0.03;
        const oldPercent = Math.round((oldBonus - 1) * 100);
        const oldStep = Math.floor(oldPercent / 15);
        if (newStep > oldStep && newStep > 0) {
          // Schedule the alert text after state update
          setTimeout(() => {
            addText(
              window.innerWidth / 2 - 60,
              window.innerHeight / 2 - 40,
              `⚡ SPEED +${newStep * 15}%!`,
              '#FBBF24',
            );
          }, 0);
        }
        return next;
      });
    }, 500);

    return () => {
      if (elapsedTimerRef.current) {
        clearInterval(elapsedTimerRef.current);
        elapsedTimerRef.current = null;
      }
    };
  }, [level, isPaused]);

  // ================================================================
  // TIMER (time-based levels)
  // ================================================================
  useEffect(() => {
    if (!level?.timeLimit || isPaused) return;

    timerIntervalRef.current = setInterval(() => {
      const current = useGameStore.getState().timeLeft;
      if (current <= 0) {
        if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
        // For time attack: completion time = the level's timeLimit
        completeLevel(level?.timeLimit || elapsedMs / 1000);
        return;
      }
      setTimeLeft(current - 1);
    }, 1000);

    return () => {
      if (timerIntervalRef.current) {
        clearInterval(timerIntervalRef.current);
        timerIntervalRef.current = null;
      }
    };
  }, [level, isPaused, setTimeLeft, completeLevel]);

  // ================================================================
  // CLEANUP
  // ================================================================
  useEffect(() => {
    return () => {
      if (spawnIntervalRef.current) clearInterval(spawnIntervalRef.current);
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      if (elapsedTimerRef.current) clearInterval(elapsedTimerRef.current);
      if (speedTimerRef.current) clearTimeout(speedTimerRef.current);
      clearPopEffects();
      clearFloatingTexts();
    };
  }, [clearPopEffects, clearFloatingTexts]);

  // ================================================================
  // PAUSE
  // ================================================================
  const togglePause = useCallback(() => setIsPaused((p) => !p), []);
  const handleResume = useCallback(() => setIsPaused(false), []);
  const handleQuit = useCallback(() => {
    setIsPaused(false);
    setScreen('levelSelect');
  }, [setScreen]);

  // ================================================================
  // DERIVED VALUES
  // ================================================================
  const maxLives = 3;
  const progress =
    level && level.goalType === 'scoreTarget'
      ? Math.min(score / level.goal, 1)
      : Math.min(pops / (level?.goal || 1), 1);
  const progressPercent = Math.min(Math.round(progress * 100), 100);
  const isTimeBased = !!level?.timeLimit;
  const isSpeedBoosted = effectiveSpeedMultiplier > 1.1;
  const isSlowed = effectiveSpeedMultiplier < 0.9;
  const speedPercent = Math.round((timeSpeedBonus - 1) * 100); // how much faster (0-100%)

  // ================================================================
  // RENDER
  // ================================================================
  if (!level) return null;

  return (
    <div className="relative w-full h-dvh overflow-hidden select-none" style={{ touchAction: 'none' }}>
      {/* ===== BACKGROUND ===== */}
      <div
        className="absolute inset-0"
        style={{
          background: 'linear-gradient(180deg, #FFF1C1 0%, #FFE0B2 30%, #FFCCBC 60%, #F8BBD0 100%)',
        }}
      />

      {/* Clouds */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div
            key={`cloud-${i}`}
            className="absolute rounded-full"
            style={{
              width: 100 + i * 40,
              height: 40 + i * 15,
              left: `${(i * 19 + 5) % 100}%`,
              top: `${8 + (i * 12) % 60}%`,
              background: 'rgba(255,255,255,0.25)',
              filter: 'blur(8px)',
            }}
          />
        ))}
      </div>

      {/* ===== GAME AREA ===== */}
      <div ref={gameAreaRef} className="absolute inset-0" style={{ zIndex: 1 }}>
        {/* Active balloons */}
        {activeBalloons.map((balloon) => (
          <Balloon
            key={balloon.id}
            id={balloon.id}
            type={balloon.type}
            x={balloon.x}
            y={balloon.y}
            speed={balloon.speed}
            onPop={handlePop}
            onMiss={handleMiss}
            gameAreaRef={gameAreaRef}
            speedMultiplier={effectiveSpeedMultiplier}
          />
        ))}

        {/* Pop effects */}
        {localEffects.map((effect) => (
          <PopEffect
            key={effect.id}
            effect={{
              id: effect.id,
              x: effect.x,
              y: effect.y,
              type: effect.type,
              timestamp: effect.timestamp,
            }}
            onComplete={handleEffectComplete}
          />
        ))}

        {/* Floating texts */}
        {localTexts.map((ft) => (
          <FloatingText
            key={ft.id}
            text={{
              id: ft.id,
              x: ft.x,
              y: ft.y,
              text: ft.text,
              color: ft.color,
              timestamp: ft.timestamp,
            }}
            onComplete={handleTextComplete}
          />
        ))}
      </div>

      {/* ===== HUD ===== */}
      <div className="absolute inset-x-0 top-0 pointer-events-none" style={{ zIndex: 100 }}>
        <div className="flex items-start justify-between px-3 pt-3 sm:px-6 sm:pt-4">
          {/* Pause */}
          <motion.button
            className="flex items-center justify-center rounded-full bg-black/20 backdrop-blur-sm
                       w-11 h-11 sm:w-12 sm:h-12 pointer-events-auto cursor-pointer"
            onClick={togglePause}
            whileTap={{ scale: 0.9 }}
            aria-label="Pause game"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-white drop-shadow-lg" />
          </motion.button>

          {/* Level name + Progress bar */}
          <div className="flex flex-col items-center gap-1.5 max-w-[45%]">
            <span className="text-sm sm:text-base font-bold text-white drop-shadow-md truncate">
              {level.emoji} {level.name}
            </span>

            {/* Progress bar */}
            <div
              className="relative w-full overflow-hidden rounded-full"
              style={{
                height: 22,
                background: 'rgba(0,0,0,0.2)',
                border: '2px solid rgba(255,255,255,0.3)',
              }}
            >
              <motion.div
                className="absolute inset-y-0 left-0 rounded-full"
                style={{
                  background: 'linear-gradient(90deg, #FBBF24 0%, #F59E0B 40%, #EF4444 100%)',
                }}
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 0.3, ease: 'easeOut' }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-[11px] sm:text-xs font-extrabold text-white drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]">
                  {level.goalType === 'scoreTarget' ? `${score}/${level.goal}` : `${pops}/${level.goal}`}
                </span>
              </div>
            </div>
          </div>

          {/* Score + Lives */}
          <div className="flex flex-col items-end gap-1.5">
            <div className="flex items-center gap-1.5 bg-black/20 backdrop-blur-sm rounded-full px-3 py-1.5">
              <Star className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-300 fill-yellow-300" />
              <span className="text-sm sm:text-base font-bold text-white drop-shadow-md tabular-nums">
                {score}
              </span>
            </div>

            {/* 3 lives */}
            <div className="flex items-center gap-0.5">
              {[0, 1, 2].map((i) => (
                <motion.span
                  key={i}
                  className="text-base sm:text-lg inline-block"
                  role="img"
                  animate={i >= lives ? { scale: [1, 1.3, 1], opacity: [1, 0.3, 0.4] } : {}}
                  transition={{ duration: 0.4 }}
                >
                  {i < lives ? '❤️' : '🖤'}
                </motion.span>
              ))}
            </div>
          </div>
        </div>

        {/* Speed indicator bar — shows time-based speed increase */}
        <div className="mx-3 sm:mx-6 mt-2">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-yellow-300 flex-shrink-0" />
            <div
              className="h-2.5 flex-1 overflow-hidden rounded-full"
              style={{ background: 'rgba(0,0,0,0.15)', border: '1px solid rgba(255,255,255,0.2)' }}
            >
              <motion.div
                className="h-full rounded-full"
                style={{
                  background: timeSpeedBonus > 1.5
                    ? 'linear-gradient(90deg, #FBBF24, #EF4444)'
                    : timeSpeedBonus > 1.25
                      ? 'linear-gradient(90deg, #FBBF24, #F97316)'
                      : 'linear-gradient(90deg, #FDE68A, #FBBF24)',
                  minWidth: '4px',
                }}
                animate={{
                  width: `${Math.min(speedPercent, 100)}%`,
                }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
              />
            </div>
            <span className="text-[10px] sm:text-xs font-bold text-yellow-200 tabular-nums min-w-[28px] text-right drop-shadow">
              +{speedPercent}%
            </span>
          </div>
        </div>

        {/* Timer (time-based levels) */}
        {isTimeBased && (
          <div className="flex justify-center mt-2">
            <motion.div
              className="flex items-center gap-1.5 rounded-full px-4 py-1.5 backdrop-blur-sm"
              style={{
                background: timeLeft <= 5 ? 'rgba(239,68,68,0.35)' : 'rgba(0,0,0,0.2)',
                border: `2px solid ${timeLeft <= 5 ? 'rgba(239,68,68,0.6)' : 'rgba(255,255,255,0.2)'}`,
              }}
              animate={timeLeft <= 5 ? { scale: [1, 1.08, 1] } : {}}
              transition={{ duration: 0.5, repeat: Infinity }}
            >
              <Clock className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: timeLeft <= 5 ? '#FCA5A5' : '#FFF' }} />
              <span
                className="text-base sm:text-lg font-extrabold tabular-nums"
                style={{ color: timeLeft <= 5 ? '#FCA5A5' : '#FFF', textShadow: '0 1px 3px rgba(0,0,0,0.5)' }}
              >
                {timeLeft}s
              </span>
            </motion.div>
          </div>
        )}

        {/* Combo */}
        <AnimatePresence>
          {combo > 2 && !isPaused && (
            <motion.div
              className="flex justify-center mt-2"
              initial={{ opacity: 0, y: -10, scale: 0.7 }}
              animate={{ opacity: 1, y: 0, scale: [1, 1.12, 1] }}
              exit={{ opacity: 0, y: -10, scale: 0.7 }}
              transition={{ opacity: { duration: 0.2 }, scale: { duration: 0.4, repeat: Infinity, repeatType: 'reverse' } }}
            >
              <div className="rounded-full px-4 py-1 backdrop-blur-sm" style={{ background: 'rgba(251,191,36,0.35)', border: '2px solid rgba(251,191,36,0.5)' }}>
                <span className="text-base sm:text-lg font-black" style={{ color: '#FDE68A', textShadow: '0 0 10px rgba(251,191,36,0.6), 0 2px 4px rgba(0,0,0,0.4)', letterSpacing: '0.05em' }}>
                  🔥 COMBO x{combo}
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Power-up indicator */}
        <AnimatePresence>
          {(isSpeedBoosted || isSlowed) && !isPaused && (
            <motion.div
              className="flex justify-center mt-1"
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
            >
              <div
                className="rounded-full px-3 py-0.5 backdrop-blur-sm text-xs sm:text-sm font-bold"
                style={{
                  background: isSpeedBoosted ? 'rgba(239,68,68,0.3)' : 'rgba(96,165,250,0.3)',
                  border: isSpeedBoosted ? '2px solid rgba(239,68,68,0.5)' : '2px solid rgba(96,165,250,0.5)',
                  color: isSpeedBoosted ? '#FCA5A5' : '#93C5FD',
                  textShadow: '0 1px 2px rgba(0,0,0,0.4)',
                }}
              >
                {isSpeedBoosted ? '🔥 SPEED UP!' : '🐢 SLOW DOWN'}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ===== DANGER ZONE indicator at top ===== */}
      <div
        className="absolute inset-x-0 top-0 pointer-events-none"
        style={{
          height: 8,
          background: 'linear-gradient(180deg, rgba(239,68,68,0.6) 0%, rgba(239,68,68,0.15) 50%, transparent 100%)',
          zIndex: 99,
        }}
      />

      {/* ===== Screen flash on life lost ===== */}
      <AnimatePresence>
        {screenFlash && (
          <motion.div
            className="absolute inset-0 pointer-events-none"
            style={{
              zIndex: 150,
              background: 'radial-gradient(ellipse at center top, rgba(239,68,68,0.4) 0%, rgba(239,68,68,0) 70%)',
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0.6, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          />
        )}
      </AnimatePresence>

      {/* ===== PAUSE OVERLAY ===== */}
      <AnimatePresence>
        {isPaused && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            style={{ zIndex: 200, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(6px)' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="flex flex-col items-center gap-6 rounded-3xl px-8 py-10 mx-4"
              style={{
                background: 'linear-gradient(180deg, #FFF8E1 0%, #FFE0B2 100%)',
                boxShadow: '0 20px 60px rgba(0,0,0,0.3), 0 0 0 4px rgba(255,255,255,0.3)',
                minWidth: 260,
              }}
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.7, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            >
              <h2 className="text-3xl sm:text-4xl font-black" style={{ color: '#7C3AED', textShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
                ⏸️ Paused
              </h2>

              <div className="flex flex-col gap-3 w-full max-w-[200px]">
                <motion.button
                  className="w-full py-3 rounded-xl text-base sm:text-lg font-bold cursor-pointer text-white shadow-lg"
                  style={{ background: 'linear-gradient(135deg, #34D399, #10B981)', boxShadow: '0 4px 14px rgba(16,185,129,0.4)' }}
                  onClick={handleResume}
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.03 }}
                >
                  ▶️ Resume
                </motion.button>

                <motion.button
                  className="w-full py-3 rounded-xl text-base sm:text-lg font-bold cursor-pointer text-white shadow-lg"
                  style={{ background: 'linear-gradient(135deg, #F87171, #EF4444)', boxShadow: '0 4px 14px rgba(239,68,68,0.4)' }}
                  onClick={handleQuit}
                  whileTap={{ scale: 0.95 }}
                  whileHover={{ scale: 1.03 }}
                >
                  🚪 Quit
                </motion.button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
