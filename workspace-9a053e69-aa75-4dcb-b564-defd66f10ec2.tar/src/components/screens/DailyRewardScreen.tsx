'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Gift, Lock, X } from 'lucide-react';
import { useGameStore } from '@/lib/gameStore';
import { playRewardSound } from '@/lib/sounds';

// ─── Daily reward amounts for each day ───────────────────────────────────────
const DAILY_REWARDS = [5, 10, 15, 20, 30, 40, 100];

// ─── Animation variants ──────────────────────────────────────────────────────
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08, delayChildren: 0.15 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 25, scale: 0.9 },
  visible: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { type: 'spring', stiffness: 280, damping: 22 },
  },
};

const coinSpin = {
  rotate: [0, 360],
  transition: {
    duration: 1.5,
    repeat: Infinity,
    ease: 'linear',
  },
};

const pulseGlow = {
  boxShadow: [
    '0 0 20px rgba(251, 191, 36, 0.3), 0 0 40px rgba(245, 158, 11, 0.15)',
    '0 0 30px rgba(251, 191, 36, 0.5), 0 0 60px rgba(245, 158, 11, 0.25)',
    '0 0 20px rgba(251, 191, 36, 0.3), 0 0 40px rgba(245, 158, 11, 0.15)',
  ],
  transition: {
    duration: 2,
    repeat: Infinity,
    ease: 'easeInOut',
  },
};

const successBurst = {
  initial: { scale: 0, opacity: 0 },
  animate: {
    scale: [0, 1.3, 1],
    opacity: [0, 1, 1],
    transition: { duration: 0.5, ease: 'easeOut' },
  },
};

// ─── Main DailyRewardScreen ──────────────────────────────────────────────────
export default function DailyRewardScreen() {
  const {
    coins,
    addCoins,
    dailyRewardLastClaimed,
    setDailyRewardClaimed,
    dailyStreak,
    setDailyStreak,
    soundEnabled,
    setScreen,
  } = useGameStore();

  const [claimed, setClaimed] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const today = new Date().toDateString();
  const alreadyClaimedToday = dailyRewardLastClaimed === today;
  const currentDay = dailyStreak < 7 ? dailyStreak : 6;
  const todayReward = DAILY_REWARDS[currentDay];

  // Sync claimed state on mount
  useEffect(() => {
    setClaimed(alreadyClaimedToday);
  }, [alreadyClaimedToday]);

  // ─── Claim reward handler ────────────────────────────────────────────
  const handleClaim = () => {
    if (claimed) return;

    addCoins(todayReward);
    setDailyRewardClaimed(today);
    setDailyStreak(dailyStreak >= 6 ? 0 : dailyStreak + 1);
    setClaimed(true);
    setShowSuccess(true);

    if (soundEnabled) playRewardSound();

    // Hide success animation after 2s
    setTimeout(() => setShowSuccess(false), 2000);
  };

  return (
    <div className="flex min-h-dvh flex-col items-center bg-gradient-to-b from-amber-200 via-orange-200 to-pink-200">
      {/* ── Success burst overlay ──────────────────────────────────────── */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center"
          >
            {/* Radial particles */}
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute h-3 w-3 rounded-full bg-yellow-400"
                initial={{ scale: 0, x: 0, y: 0 }}
                animate={{
                  scale: [0, 1, 0],
                  x: Math.cos((i * Math.PI * 2) / 12) * 120,
                  y: Math.sin((i * Math.PI * 2) / 12) * 120,
                }}
                transition={{ duration: 0.8, ease: 'easeOut' }}
              />
            ))}
            {/* Big coin */}
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: [0, 1.5, 1] }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="text-8xl"
            >
              🪙
            </motion.div>
            {/* +coins text */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: -40, opacity: [0, 1, 0] }}
              transition={{ duration: 1.5, delay: 0.3 }}
              className="absolute bottom-40 text-3xl font-extrabold text-yellow-600"
            >
              +{todayReward} 🪙
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Header ─────────────────────────────────────────────────────── */}
      <motion.header
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20 }}
        className="w-full px-4 py-3 sm:px-6"
      >
        <div className="flex items-center justify-between">
          <div className="w-12" />
          <div className="flex items-center gap-2">
            <span className="text-2xl">🎁</span>
            <h1 className="text-2xl font-extrabold text-orange-800 sm:text-3xl">
              Daily Reward!
            </h1>
          </div>
          <motion.button
            onClick={() => setScreen('home')}
            className="flex h-12 w-12 items-center justify-center rounded-full bg-white/70 shadow-md backdrop-blur-sm"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            <X className="h-6 w-6 text-orange-700" />
          </motion.button>
        </div>
      </motion.header>

      {/* ── Main content ───────────────────────────────────────────────── */}
      <motion.div
        className="flex w-full max-w-lg flex-1 flex-col items-center gap-6 px-4 pt-2 pb-8"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Streak indicator */}
        <motion.div
          variants={itemVariants}
          className="flex items-center gap-2 rounded-full bg-white/60 px-5 py-2 shadow-sm backdrop-blur-sm"
        >
          <span className="text-lg">🔥</span>
          <span className="text-base font-bold text-orange-700 sm:text-lg">
            {dailyStreak} Day Streak!
          </span>
        </motion.div>

        {/* ── 7-day calendar ───────────────────────────────────────────── */}
        <motion.div
          variants={itemVariants}
          className="w-full overflow-x-auto rounded-2xl bg-white/60 p-3 shadow-lg backdrop-blur-sm"
        >
          <div className="flex min-w-[420px] gap-2 sm:min-w-0">
            {DAILY_REWARDS.map((reward, day) => {
              const isClaimed = day < dailyStreak;
              const isToday = day === currentDay && !alreadyClaimedToday;
              const isLocked = day > currentDay || alreadyClaimedToday;

              return (
                <motion.div
                  key={day}
                  className={`relative flex flex-1 flex-col items-center gap-1 rounded-xl p-2 transition-all ${
                    isClaimed
                      ? 'bg-green-100 border-2 border-green-300'
                      : isToday
                        ? 'bg-amber-50 border-2 border-amber-400'
                        : 'bg-white/50 border-2 border-white/40'
                  }`}
                  whileHover={{ y: -2 }}
                  animate={isToday ? pulseGlow : {}}
                >
                  {/* Day label */}
                  <span className="text-xs font-bold text-gray-500 sm:text-sm">
                    Day {day + 1}
                  </span>

                  {/* Reward coin */}
                  <div className="relative flex h-10 w-10 items-center justify-center">
                    {isClaimed ? (
                      <motion.div
                        initial={false}
                        className="flex h-9 w-9 items-center justify-center rounded-full bg-green-500 shadow-md"
                      >
                        <Check className="h-5 w-5 text-white" />
                      </motion.div>
                    ) : isLocked ? (
                      <motion.div
                        initial={false}
                        className="flex h-9 w-9 items-center justify-center rounded-full bg-gray-200"
                      >
                        <Lock className="h-4 w-4 text-gray-400" />
                      </motion.div>
                    ) : (
                      <motion.div
                        initial={false}
                        animate={coinSpin}
                        className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-b from-yellow-300 to-amber-500 shadow-md"
                      >
                        <span className="text-sm">🪙</span>
                      </motion.div>
                    )}
                  </div>

                  {/* Reward amount */}
                  <span
                    className={`text-xs font-bold ${
                      isClaimed
                        ? 'text-green-600'
                        : isLocked
                          ? 'text-gray-400'
                          : 'text-amber-700'
                    }`}
                  >
                    {reward}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* ── Today's reward display ───────────────────────────────────── */}
        <motion.div
          variants={itemVariants}
          className="flex w-full flex-col items-center gap-4 rounded-3xl bg-white/70 p-6 shadow-xl backdrop-blur-sm"
        >
          <h2 className="text-xl font-extrabold text-orange-800 sm:text-2xl">
            Today&apos;s Reward!
          </h2>

          {/* Big animated coin */}
          <motion.div
            className="relative flex flex-col items-center gap-2"
            animate={
              claimed
                ? {}
                : {
                    y: [0, -8, 0],
                    transition: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
                  }
            }
          >
            <motion.div
              animate={!claimed ? coinSpin : {}}
              className="flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-b from-yellow-300 via-amber-400 to-yellow-600 shadow-2xl sm:h-28 sm:w-28"
            >
              <span className="text-5xl sm:text-6xl">🪙</span>
            </motion.div>
            <motion.span
              key={claimed ? 'claimed' : 'unclaimed'}
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-3xl font-extrabold text-amber-700 sm:text-4xl"
            >
              {todayReward}
            </motion.span>
          </motion.div>

          {/* Claim button / already claimed message */}
          {claimed ? (
            <motion.div
              initial={successBurst.initial}
              animate={successBurst.animate}
              className="flex flex-col items-center gap-3"
            >
              <div className="flex h-14 items-center justify-center rounded-2xl bg-green-400 px-8 shadow-lg">
                <span className="text-xl font-extrabold text-white">
                  Claimed! ✓
                </span>
              </div>
              <div className="flex items-center gap-2 text-base text-gray-500 sm:text-lg">
                <span>🕐</span>
                <span>Come back tomorrow!</span>
              </div>
              <p className="text-sm text-gray-400">
                Next reward:{' '}
                <span className="font-bold text-amber-600">
                  🪙 {DAILY_REWARDS[dailyStreak >= 7 ? 0 : dailyStreak]} coins
                </span>
              </p>
            </motion.div>
          ) : (
            <motion.button
              onClick={handleClaim}
              className="flex h-14 min-w-[200px] items-center justify-center rounded-2xl bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 px-10 text-xl font-extrabold text-white shadow-lg sm:h-16 sm:text-2xl"
              whileHover={{ scale: 1.08, rotate: [-1, 1, -1, 0] }}
              whileTap={{ scale: 0.95 }}
              animate={{
                boxShadow: [
                  '0 4px 20px rgba(251, 191, 36, 0.4), inset 0 -3px 6px rgba(0,0,0,0.08)',
                  '0 8px 30px rgba(245, 158, 11, 0.5), inset 0 -3px 6px rgba(0,0,0,0.08)',
                  '0 4px 20px rgba(251, 191, 36, 0.4), inset 0 -3px 6px rgba(0,0,0,0.08)',
                ],
              }}
              transition={{
                boxShadow: { duration: 2, repeat: Infinity, ease: 'easeInOut' },
              }}
              style={{ textShadow: '1px 2px 3px rgba(0,0,0,0.2)' }}
            >
              <Gift className="mr-2 h-6 w-6 sm:h-7 sm:w-7" />
              Claim Reward!
            </motion.button>
          )}
        </motion.div>

        {/* ── Current coins display ────────────────────────────────────── */}
        <motion.div
          variants={itemVariants}
          className="flex items-center gap-3 rounded-full bg-white/60 px-6 py-3 shadow-md backdrop-blur-sm"
        >
          <span className="text-2xl">💰</span>
          <span className="text-base font-bold text-gray-600">Your coins:</span>
          <motion.span
            key={coins}
            initial={{ scale: 1.4, color: '#d97706' }}
            animate={{ scale: 1, color: '#92400e' }}
            className="text-2xl font-extrabold text-yellow-800"
          >
            {coins}
          </motion.span>
        </motion.div>

        {/* ── Close button ─────────────────────────────────────────────── */}
        <motion.button
          variants={itemVariants}
          onClick={() => setScreen('home')}
          className="flex h-12 min-w-[180px] items-center justify-center rounded-full bg-white/70 px-8 text-base font-bold text-orange-700 shadow-md backdrop-blur-sm transition-colors hover:bg-white/90 sm:text-lg"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Close
        </motion.button>
      </motion.div>
    </div>
  );
}
