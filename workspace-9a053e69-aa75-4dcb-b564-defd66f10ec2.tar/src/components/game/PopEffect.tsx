'use client';

import { useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BALLOON_CONFIG } from '@/lib/levels';
import type { PopEffect as PopEffectType } from '@/lib/gameStore';

interface PopEffectProps {
  effect: PopEffectType;
  onComplete: (id: string) => void;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  color: string;
  size: number;
  angle: number;
  distance: number;
}

export default function PopEffect({ effect, onComplete }: PopEffectProps) {
  const config = BALLOON_CONFIG[effect.type as keyof typeof BALLOON_CONFIG] || BALLOON_CONFIG.silly;

  // Generate particles in a radial burst pattern
  const particles = useMemo<Particle[]>(() => {
    const count = 10;
    const colors = [config.color, config.secondaryColor, '#FFFFFF', '#FCD34D', config.color];
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      x: 0,
      y: 0,
      color: colors[i % colors.length],
      size: 4 + Math.random() * 6,
      angle: (360 / count) * i + Math.random() * 20 - 10,
      distance: 30 + Math.random() * 40,
    }));
  }, [config.color, config.secondaryColor]);

  // Auto-remove after animation completes
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete(effect.id);
    }, 600);
    return () => clearTimeout(timer);
  }, [effect.id, onComplete]);

  return (
    <AnimatePresence>
      <div
        className="absolute pointer-events-none"
        style={{
          left: effect.x,
          top: effect.y,
          zIndex: 50,
        }}
      >
        {/* Expanding ring */}
        <motion.div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2"
          style={{
            borderColor: config.color,
            width: 20,
            height: 20,
          }}
          initial={{ scale: 0.3, opacity: 0.8 }}
          animate={{ scale: 3.5, opacity: 0 }}
          transition={{ duration: 0.45, ease: 'easeOut' }}
        />

        {/* Second ring (white, slightly delayed) */}
        <motion.div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2"
          style={{
            borderColor: 'rgba(255,255,255,0.6)',
            width: 16,
            height: 16,
          }}
          initial={{ scale: 0.2, opacity: 0.6 }}
          animate={{ scale: 2.5, opacity: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut', delay: 0.05 }}
        />

        {/* Burst particles */}
        {particles.map((particle) => {
          const angleRad = (particle.angle * Math.PI) / 180;
          const endX = Math.cos(angleRad) * particle.distance;
          const endY = Math.sin(angleRad) * particle.distance;

          return (
            <motion.div
              key={particle.id}
              className="absolute left-1/2 top-1/2 rounded-full"
              style={{
                width: particle.size,
                height: particle.size,
                backgroundColor: particle.color,
                marginLeft: -particle.size / 2,
                marginTop: -particle.size / 2,
                boxShadow: `0 0 ${particle.size}px ${particle.color}88`,
              }}
              initial={{ x: 0, y: 0, scale: 1, opacity: 1 }}
              animate={{
                x: endX,
                y: endY,
                scale: 0,
                opacity: 0,
              }}
              transition={{
                duration: 0.5,
                ease: 'easeOut',
              }}
            />
          );
        })}

        {/* Central emoji flash */}
        <motion.div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center justify-center"
          initial={{ scale: 0.8, opacity: 1 }}
          animate={{ scale: 2.5, opacity: 0 }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
        >
          <span style={{ fontSize: 28 }}>{config.emoji}</span>
        </motion.div>

        {/* Flash overlay */}
        <motion.div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full"
          style={{
            background: `radial-gradient(circle, rgba(255,255,255,0.6) 0%, transparent 70%)`,
            width: 40,
            height: 40,
          }}
          initial={{ scale: 0.5, opacity: 1 }}
          animate={{ scale: 2, opacity: 0 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
        />
      </div>
    </AnimatePresence>
  );
}
