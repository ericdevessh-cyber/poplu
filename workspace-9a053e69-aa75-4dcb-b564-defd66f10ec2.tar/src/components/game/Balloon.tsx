'use client';

import { useRef, useCallback, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { BALLOON_CONFIG } from '@/lib/levels';

interface BalloonProps {
  id: string;
  type: string;
  x: number;
  y: number;
  speed: number;
  onPop: (id: string, type: string, x: number, y: number) => void;
  onMiss: (id: string) => void;
  gameAreaRef: React.RefObject<HTMLDivElement>;
  speedMultiplier: number;
}

function randomBetween(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

export default function Balloon({
  id,
  type,
  x,
  y: initialY,
  speed,
  onPop,
  onMiss,
  gameAreaRef,
  speedMultiplier,
}: BalloonProps) {
  const hasPopped = useRef(false);
  const hasMissed = useRef(false);
  const rafRef = useRef<number>(0);
  const wobbleOffset = useRef(randomBetween(0, Math.PI * 2));
  const wobbleSpeed = useRef(randomBetween(1.5, 3));
  const wobbleAmount = useRef(randomBetween(8, 16));
  const prevTime = useRef(Date.now());
  const mountedRef = useRef(false);

  // Store props in refs so rAF loop never goes stale
  const onPopRef = useRef(onPop);
  onPopRef.current = onPop;
  const onMissRef = useRef(onMiss);
  onMissRef.current = onMiss;
  const gameAreaRefStable = useRef(gameAreaRef);
  gameAreaRefStable.current = gameAreaRef;
  const speedRef = useRef(speed);
  speedRef.current = speed;
  const multRef = useRef(speedMultiplier);
  multRef.current = speedMultiplier;

  const [pos, setPos] = useState({ x, y: initialY });
  const [popped, setPopped] = useState(false);

  const config = BALLOON_CONFIG[type as keyof typeof BALLOON_CONFIG] || BALLOON_CONFIG.silly;
  const color = config.color;
  const secondaryColor = config.secondaryColor;
  const emoji = config.emoji;
  const posRef = useRef({ x, y: initialY });

  // ---- rAF loop — only depends on `id` (never re-starts mid-flight) ----
  useEffect(() => {
    prevTime.current = Date.now();
    mountedRef.current = true;

    const animate = () => {
      if (hasPopped.current || hasMissed.current) return;

      const now = Date.now();
      const delta = (now - prevTime.current) / 16.67;
      prevTime.current = now;

      // move up
      posRef.current.y -= speedRef.current * multRef.current * delta;

      // wobble
      const t = now / 1000;
      posRef.current.x = x + Math.sin(t * wobbleSpeed.current + wobbleOffset.current) * wobbleAmount.current;

      // MISS CHECK — balloon touches the TOP of the screen = lose a life!
      // Trigger when balloon's top edge reaches y=0 (not when fully off-screen)
      if (posRef.current.y <= 0) {
        hasMissed.current = true;
        onMissRef.current(id);
        return;
      }

      if (mountedRef.current) {
        setPos({ x: posRef.current.x, y: posRef.current.y });
      }

      rafRef.current = requestAnimationFrame(animate);
    };

    const timer = setTimeout(() => {
      rafRef.current = requestAnimationFrame(animate);
    }, 10);

    return () => {
      mountedRef.current = false;
      clearTimeout(timer);
      cancelAnimationFrame(rafRef.current);
    };
  }, [id, x, initialY]);

  // ---- pop handler ----
  const handlePop = useCallback(
    (e: React.MouseEvent | React.TouchEvent) => {
      e.preventDefault();
      e.stopPropagation();
      if (hasPopped.current || hasMissed.current) return;

      hasPopped.current = true;
      cancelAnimationFrame(rafRef.current);

      // actual tap coords
      let cx: number, cy: number;
      if ('changedTouches' in e && e.changedTouches?.length) {
        cx = e.changedTouches[0].clientX;
        cy = e.changedTouches[0].clientY;
      } else {
        cx = (e as React.MouseEvent).clientX;
        cy = (e as React.MouseEvent).clientY;
      }

      const ga = gameAreaRef.current;
      const popX = ga ? cx - ga.getBoundingClientRect().left : posRef.current.x;
      const popY = ga ? cy - ga.getBoundingClientRect().top : posRef.current.y;

      setPopped(true);
      onPop(id, type, popX, popY);
    },
    [id, type, onPop, gameAreaRef],
  );

  const isGolden = type === 'golden';
  const isBomb = type === 'bomb';
  const isSlow = type === 'slow';
  const isSpeed = type === 'speed';

  return (
    <motion.div
      className="absolute cursor-pointer select-none"
      style={{
        // KEY FIX: use left/top for positioning, NOT transform
        // framer-motion owns transform (for scale/opacity) so we must not override it
        left: pos.x,
        top: pos.y,
        zIndex: isGolden ? 20 : 10,
        touchAction: 'none',
        minWidth: 60,
        minHeight: 60,
        willChange: 'left, top, transform',
      }}
      initial={{ scale: 0, opacity: 0 }}
      animate={
        popped
          ? { scale: [1, 1.4, 0], opacity: [1, 1, 0] }
          : { scale: 1, opacity: 1 }
      }
      transition={
        popped
          ? { duration: 0.2, ease: 'easeOut' }
          : { duration: 0.25, ease: 'easeOut' }
      }
      onClick={handlePop}
      onTouchStart={handlePop}
    >
      {/* Golden glow */}
      {isGolden && (
        <motion.div
          className="absolute inset-[-6px] rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(251,191,36,0.5) 0%, rgba(251,191,36,0) 70%)',
          }}
          animate={{ scale: [1, 1.15, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 1, repeat: Infinity, ease: 'easeInOut' }}
        />
      )}

      {/* Slow aura */}
      {isSlow && (
        <motion.div
          className="absolute inset-[-8px] rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(96,165,250,0.35) 0%, rgba(96,165,250,0) 70%)',
          }}
          animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        />
      )}

      {/* Speed flames */}
      {isSpeed && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex gap-0.5">
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="rounded-full"
              style={{
                width: 6,
                height: 10,
                background: `linear-gradient(to top, ${secondaryColor}, #FCD34D)`,
              }}
              animate={{ y: [-2, -14, -8], opacity: [1, 0.3, 0], scale: [1, 0.6, 0.3] }}
              transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2, ease: 'easeOut' }}
            />
          ))}
        </div>
      )}

      {/* Bomb fuse */}
      {isBomb && (
        <div className="absolute -top-2 left-1/2 -translate-x-1/2">
          <div className="h-3 w-[2px] rounded-full" style={{ background: '#9CA3AF' }} />
          <motion.div
            className="absolute -top-1.5 left-1/2 -translate-x-1/2 rounded-full"
            style={{
              width: 8,
              height: 8,
              background: 'radial-gradient(circle, #FDE68A 0%, #F59E0B 50%, transparent 70%)',
            }}
            animate={{ scale: [1, 1.5, 1], opacity: [1, 0.6, 1] }}
            transition={{ duration: 0.3, repeat: Infinity, ease: 'easeInOut' }}
          />
        </div>
      )}

      {/* Balloon body */}
      <div
        className="relative"
        style={{ width: 'clamp(60px, 10vw, 90px)', height: 'clamp(70px, 12vw, 100px)' }}
      >
        <div
          className="w-full h-full rounded-[50%_50%_50%_50%/60%_60%_40%_40%] relative"
          style={{
            background: `radial-gradient(circle at 35% 30%, ${color}, ${secondaryColor})`,
            boxShadow: isBomb
              ? '0 4px 12px rgba(0,0,0,0.4), inset 0 -8px 16px rgba(0,0,0,0.3)'
              : `0 4px 16px ${secondaryColor}66, inset 0 -6px 12px rgba(0,0,0,0.15)`,
            border: `2px solid ${secondaryColor}`,
          }}
        >
          {/* Shine */}
          <div
            className="absolute rounded-full"
            style={{
              width: '35%',
              height: '25%',
              top: '12%',
              left: '18%',
              background: 'radial-gradient(ellipse at center, rgba(255,255,255,0.7) 0%, rgba(255,255,255,0.2) 40%, transparent 70%)',
              transform: 'rotate(-20deg)',
            }}
          />

          {/* Emoji */}
          <div className="absolute inset-0 flex items-center justify-center">
            <span
              className="drop-shadow-md"
              style={{
                fontSize: 'clamp(24px, 5vw, 36px)',
                lineHeight: 1,
                filter: isBomb ? 'none' : 'drop-shadow(0 1px 2px rgba(0,0,0,0.15))',
              }}
            >
              {emoji}
            </span>
          </div>
        </div>

        {/* Knot */}
        <div className="absolute -bottom-[2px] left-1/2 -translate-x-1/2">
          <div
            className="w-0 h-0"
            style={{
              borderLeft: '5px solid transparent',
              borderRight: '5px solid transparent',
              borderTop: `8px solid ${secondaryColor}`,
            }}
          />
        </div>

        {/* String */}
        <div className="absolute left-1/2 -translate-x-1/2" style={{ top: '100%' }}>
          <svg width="2" height="24" viewBox="0 0 2 24" fill="none" className="opacity-60">
            <path
              d="M1 0 C0.5 6, 1.5 12, 1 18 C0.5 21, 1 23, 1 24"
              stroke="#9CA3AF"
              strokeWidth="1.5"
              strokeLinecap="round"
              fill="none"
            />
          </svg>
        </div>
      </div>

      {/* Touch target */}
      <div
        className="absolute inset-0"
        style={{ minWidth: 44, minHeight: 44, padding: '8px', margin: '-8px' }}
      />
    </motion.div>
  );
}
