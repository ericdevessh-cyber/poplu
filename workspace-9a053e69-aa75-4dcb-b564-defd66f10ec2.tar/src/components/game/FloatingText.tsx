'use client';

import { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { FloatingText as FloatingTextType } from '@/lib/gameStore';

interface FloatingTextProps {
  text: FloatingTextType;
  onComplete: (id: string) => void;
}

export default function FloatingText({ text, onComplete }: FloatingTextProps) {
  // Determine font styling based on text content
  const isCombo = text.text.toLowerCase().includes('combo');
  const isLarge = isCombo || text.text.includes('+5') || text.text.includes('+10');

  // Auto-remove after animation
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete(text.id);
    }, 1200);
    return () => clearTimeout(timer);
  }, [text.id, onComplete]);

  return (
    <AnimatePresence>
      <motion.div
        className="absolute pointer-events-none whitespace-nowrap"
        style={{
          left: text.x,
          top: text.y,
          zIndex: 60,
          transform: 'translateX(-50%)',
        }}
        initial={{ opacity: 1, y: 0, scale: 0.5 }}
        animate={{
          opacity: [1, 1, 0],
          y: [0, -50, -80],
          scale: [0.5, isLarge ? 1.3 : 1.1, 0.8],
        }}
        exit={{ opacity: 0 }}
        transition={{
          duration: 1.1,
          ease: 'easeOut',
          times: [0, 0.4, 1],
        }}
      >
        {/* Text shadow / outline for readability */}
        <span
          className="font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]"
          style={{
            color: text.color || '#FFFFFF',
            fontSize: isLarge ? 'clamp(28px, 6vw, 44px)' : 'clamp(22px, 4vw, 32px)',
            textShadow: `
              0 0 8px ${text.color || '#FFFFFF'}88,
              0 0 16px ${text.color || '#FFFFFF'}44,
              -1px -1px 0 rgba(0,0,0,0.6),
              1px -1px 0 rgba(0,0,0,0.6),
              -1px 1px 0 rgba(0,0,0,0.6),
              1px 1px 0 rgba(0,0,0,0.6)
            `,
            WebkitTextStroke: isCombo ? '1px rgba(0,0,0,0.3)' : undefined,
            letterSpacing: isCombo ? '0.05em' : undefined,
          }}
        >
          {text.text}
        </span>
      </motion.div>
    </AnimatePresence>
  );
}
